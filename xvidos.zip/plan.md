# xvidos পরিকল্পনা

## বাস্তবায়ন পদ্ধতি

xvidos হবে একটি উন্মুক্ত, লগইনবিহীন ভিডিও আর্কাইভ। React/Vite ফ্রন্টএন্ডে ফাইল পিকার, আপলোড স্ট্যাটাস, ভিডিও গ্যালারি এবং native HTML5 video controls থাকবে। Express/tRPC backend trusted same-origin streaming route দিয়ে সর্বোচ্চ ৫০ MB ভিডিও managed object storage-এ forward করবে; browser cross-origin presigned PUT-এ না গিয়ে CORS/network interruption এড়াবে। MySQL-এ ভিডিওর index metadata থাকবে; server-side re-encode বা visual processing ছাড়া bytes সংরক্ষিত থাকবে।

প্রয়োজনীয় capability: managed Server, Database এবং Storage। Homepage public থাকবে এবং video upload-এর জন্য কোনো login gate থাকবে না, কিন্তু header-এ দৃশ্যমান Gmail OAuth `SIGN IN WITH GMAIL`/`LOG OUT` controls থাকবে। Signed-in Home user এবং Admin panel প্রতি ১৫ সেকেন্ডে heartbeat পাঠাবে; Admin ৪৫ সেকেন্ড threshold-এ online/offline দেখাবে। Signed-in video player ৫ সেকেন্ড অন্তর watch progress aggregate করে `videoWatchStats` table-এ user, Gmail/name, video title/file, accumulated seconds এবং derived `UNIT XV-<videoId>` code রাখবে; Admin ৫ সেকেন্ডে watch activity refresh করবে। Video upload-এর original file unchanged রেখে server-side ffmpeg processing-এ 144p/240p/360p/480p/720p/1080p MP4 variants তৈরি হবে, `videos.qualityVariants` metadata-তে source URL রাখা হবে এবং Homepage player selected quality source-এ switch করবে; production container ffmpeg install করবে। Admin-controlled `siteSettings` table homepage-এর Daily Captcha Reward block hide/unhide করবে এবং default `captchaDailyLimit=20`, `captchaRewardPoints=10` (১০ পয়সা); Admin ১–১০০০-এর মধ্যে daily limit এবং ১–১০,০০০ পয়সার মধ্যে per-Captcha reward replace করতে পারবে, server claim enforcement ও Homepage copy একই setting পড়বে। Existing Sonner toast layer Home/Admin success ও error feedback দেখাবে; Admin-এর `siteNotifications` broadcast table ও `admin.sendNotification` mutation title/message সকল Homepage visitor-এর কাছে সর্বোচ্চ ৫ সেকেন্ডে toast পাঠাবে; Dark/Light toggle-এর পাশে signed-in human icon Wallet Center থাকবে, যেখানে `walletCenter.summary` প্রতি ৪ সেকেন্ডে transaction history, request status, Admin note, daily Captcha earning, ৳100 minimum withdraw এবং `balanceAuditLogs` দেখাবে; application-owned `/manifest.webmanifest`, xvidos icon ও production service worker mobile install prompt/standalone app experience দেবে। Captcha input দিয়ে `Sign in & submit` চাপলে token/answer session storage-এ রেখে OAuth callback-এর পর auto-submit হবে। `/admin`-এ email submit-এর পর platform OAuth verification হবে; server-side middleware কেবল `afsiarmd@gmail.com` session email-কে admin হিসেবে অনুমোদন করবে। Successful ৬-character alphanumeric Captcha-তে Admin-configured points database balance-এ যোগ হবে; ভুল code-এ ০; configured daily limit server-side enforce হবে। Main balance strip-এ BDT balance, Withdraw ও Recharge request form থাকবে এবং `walletRequests` table-এ pending/approved/rejected lifecycle থাকবে; request submit-এর সময় transaction-এর মধ্যে requested points balance থেকে debit/reserve হবে, insufficient balance হলে request reject হবে, এবং Admin reject করলে একবার refund হবে; Admin user row থেকে BDT Add/Deduct points balance-এ প্রয়োগ হবে; ১০০ BDT = ১০,০০০ points; প্রতি recharge request-এর maximum ৳৫০; provider credentials না দেওয়া পর্যন্ত automatic payout/recharge করা হবে না।

## Project structure

- `client/src/pages/Home.tsx`: প্রধান upload + gallery workspace, filter/search, selected video player এবং empty/loading/error states।
- `client/src/index.css`: neon video vault visual system, responsive layout, native video presentation এবং motion।
- `server/routers.ts`: public video list, upload initialization এবং complete upload procedures।
- `client/src/pages/Admin.tsx`: approved Gmail submit, OAuth return এবং admin-only upload workspace।
- `server/storage.ts`: managed storage presign/stream helper ও stable `/manus-storage/...` asset path।
- `server/db.ts`: video index query ও insert helpers।
- `drizzle/schema.ts` এবং `drizzle/0001_videos.sql`: durable video metadata schema/migration।
- `public/manus-routes.json`: page route manifest।

## Design

সম্ভাব্য দিকনির্দেশনা:

1. `0.07` — Neo Brutalist Upload Desk: কড়া বর্ডার, বড় লেবেল, utility-first archive desk।
2. `0.06` — Quiet Editorial Archive: অফ-হোয়াইট পৃষ্ঠা, টাইপোগ্রাফি-নির্ভর media index।
3. `0.08` — Neon Video Vault: গভীর কালো পটভূমি, বৈদ্যুতিক বেগুনি accent এবং বড় video surfaces; নির্বাচিত।

### নির্বাচিত Design Movement

Neon Video Vault — একটি আধুনিক, সিনেমাটিক media vault যেখানে surrounding UI-তে electric violet signal থাকবে, কিন্তু uploaded video নিজে সম্পূর্ণ untouched থাকবে।

### Core Principles

- ভিডিওই hero: interface নিয়ন্ত্রিত, playback surface বড়, decorative layer ভিডিওর উপর নয়।
- স্পষ্ট স্ট্যাটাস: upload queue, percent, success/failure এবং storage promise এক নজরে বোঝা যাবে।
- প্রামাণিক archive: filename, size, type, upload time-এর মতো file facts prominent থাকবে।
- কম friction: login ছাড়া এক click-এ gallery/file picker, mobile-first controls।

### Color Philosophy

#0B0B12-এর কালো-নীল canvas ভিডিওর আলোকে foreground করে। #8B5CF6 electric violet brand signal হিসেবে action, focus এবং selection বোঝাবে; muted lavender text hierarchy তৈরি করবে। সতর্কতার জন্য warm amber এবং error-এর জন্য coral ব্যবহার হবে, যাতে violet-এর brand signature দুর্বল না হয়।

### Layout Paradigm

একটি staggered archive desk: compact header-এর নিচে বাম দিকে upload rail এবং ডান দিকে gallery field; নির্বাচিত ভিডিও gallery field-এর ওপর wide player dock-এ উঠে আসবে। ছোট viewport-এ rail top strip-এ রূপ নেবে এবং gallery এক কলামে stack হবে।

### Signature Elements

- corner-bracket upload dropzone, যেন signal lock করা হচ্ছে।
- thin violet scan-line divider এবং mono file metadata labels।
- selected video-র জন্য “ORIGINAL / UNTOUCHED” stamp-style status pill।

### Interaction Philosophy

কোনো login gate বা modal tour থাকবে না। file picker native থাকবে, drag-and-drop-ও একই upload path ব্যবহার করবে। progress visible হবে, complete হলে gallery-তে card insert হবে; failure হলে actionable retry text থাকবে। Video playback browser-এর native controls-এ থাকবে, কোনো overlay filter/frame নয়।

### Animation

Page load-এ subtle 180ms fade/slide; upload progress linear violet glow; gallery cards hover-এ মাত্র 2px lift ও thumbnail scale 1.015। Video pixels-এর ওপর কোনো animation বা overlay নয়। prefers-reduced-motion হলে সব transform বন্ধ থাকবে।

### Typography System

Bangla headings এবং UI labels-এর জন্য Hind Siliguri; file facts এবং upload state-এর জন্য ui-monospace। Display heading 52/0.95 desktop, 38/1 mobile; body 15/1.6; metadata 11/1.2 uppercase letter-spaced।

### Brand Essence

নিজের ভিডিওকে কোনো পরিবর্তন ছাড়াই দ্রুত প্রকাশ করার open media vault — সরাসরি, নির্ভেজাল, signal-driven। Personality: open, precise, cinematic.

### Brand Voice

Headline: “আপনার ভিডিও। ঠিক যেভাবে আছে।”
CTA: “ভিডিও যোগ করুন” / “আসল ফাইল সংরক্ষিত হয়েছে”। Copy সংক্ষিপ্ত, confident এবং file-first হবে।

### Wordmark & Logo

`xvidos` wordmark lowercase-এ compact geometric treatment; `x`-এর দুই stroke একটি play-chevron signal-এর মতো intersect করবে। App metadata-তে ছোট violet-on-black SVG mark থাকবে।

### Signature Brand Color

Electric violet `#8B5CF6` — upload progress, active selection, focus ring এবং brand mark-এর ownable signal color।

## Data flow

1. User file picker/dropzone-এ ভিডিও নির্বাচন করে।
2. Client `videos.createUpload`-এ filename, MIME এবং byte size পাঠায়।
3. Client same-origin `/api/videos/upload`-এ XHR stream করে; server bytes managed storage-এ forward করে এবং progress event দেখায়।
4. সফল হলে client `videos.complete`-এ server-returned storage key ও duration পাঠায়; server database row `pending` status-এ তৈরি করে।
5. Admin queue থেকে Confirm করলে status `approved`, Reject করলে `rejected`; homepage `videos.list` শুধু approved + visible row ফেরত দেয়।
6. Admin users query-তে presence, points adjustment, ban/unban থাকবে; ৮ সেকেন্ড polling-এ user state refresh হবে। Admin video switch visibility database-এ visible/hidden বদলাবে এবং homepage ৫ সেকেন্ড polling-এ reflect করবে।
7. Approved row stable `/manus-storage/<key>` URL দিয়ে native `<video>`-তে ব্যবহৃত হয়।

## Scope constraints

লগইন, sign-up, account ownership, video filter, film, frame, crop, re-encode, transcoding বা visual alteration থাকবে না। Public gallery-তে source file-র aspect ratio/controls untouched থাকবে।
