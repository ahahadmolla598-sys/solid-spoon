import { AlertCircle, ArrowLeft, Check, CloudUpload, FileVideo, History, Loader2, LogOut, Search, ShieldCheck, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { toast } from "sonner";

const ADMIN_EMAIL = "afsiarmd@gmail.com";
const MAX_VIDEO_BYTES = 50 * 1024 * 1024;

function uploadWithProgress(file: File, url: string, onProgress: (value: number) => void) {
  return new Promise<{ key: string; qualityVariants: Array<{ label: string; url: string; height: number }> }>((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("PUT", url);
    request.setRequestHeader("X-Upload-File-Name", encodeURIComponent(file.name));
    request.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    request.upload.onprogress = (event) => event.lengthComputable && onProgress(Math.min(99, Math.round((event.loaded / event.total) * 100)));
    request.onload = () => {
      if (request.status >= 200 && request.status < 300) {
        try { const result = JSON.parse(request.responseText) as { key?: string; qualityVariants?: Array<{ label: string; url: string; height: number }> }; if (result.key) return resolve({ key: result.key, qualityVariants: result.qualityVariants ?? [] }); } catch {}
      }
      let message = `Upload failed (${request.status})`;
      try { const result = JSON.parse(request.responseText) as { error?: string }; if (result.error) message = result.error; } catch {}
      reject(new Error(message));
    };
    request.onerror = () => reject(new Error("Upload connection failed"));
    request.send(file);
  });
}

function getDuration(file: File) {
  return new Promise<number | null>((resolve) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.onloadedmetadata = () => { URL.revokeObjectURL(url); resolve(Number.isFinite(video.duration) ? Math.round(video.duration) : null); };
    video.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
    video.src = url;
  });
}

export default function Admin() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<{ type: "idle" | "error" | "uploading" | "success"; message?: string; percent?: number }>({ type: "idle" });
  const [balanceStatus, setBalanceStatus] = useState<{ type: "error" | "success"; message: string } | null>(null);
  const [captchaLimitInput, setCaptchaLimitInput] = useState("20");
  const [captchaLimitStatus, setCaptchaLimitStatus] = useState<string | null>(null);
  const [captchaRewardInput, setCaptchaRewardInput] = useState("10");
  const [captchaRewardStatus, setCaptchaRewardStatus] = useState<string | null>(null);
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [notificationCategory, setNotificationCategory] = useState<"broadcast" | "new_video" | "wallet" | "security" | "system">("broadcast");
  const [notificationRecipient, setNotificationRecipient] = useState("");
  const [notificationSchedule, setNotificationSchedule] = useState("");
  const [now, setNow] = useState(() => Date.now());
  const [balanceInputs, setBalanceInputs] = useState<Record<string, string>>({});
  const [reviewNotes, setReviewNotes] = useState<Record<number, string>>({});
  const [videoCategory, setVideoCategory] = useState("General");
  const [videoTags, setVideoTags] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const me = trpc.admin.me.useQuery(undefined, { retry: false });
  const createUpload = trpc.admin.createUpload.useMutation();
  const complete = trpc.admin.complete.useMutation();
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => { window.location.href = "/admin"; } });
  const isAdmin = Boolean(me.data?.email);
  const heartbeat = trpc.auth.heartbeat.useMutation({ onError: (error) => console.warn("[Presence] heartbeat failed", error.message) });
  const pending = trpc.admin.pending.useQuery(undefined, { enabled: isAdmin, retry: false });
  const approve = trpc.admin.approve.useMutation({ onSuccess: () => pending.refetch() });
  const reject = trpc.admin.reject.useMutation({ onSuccess: () => pending.refetch() });
  const users = trpc.admin.users.useQuery({ search: userSearch }, { enabled: isAdmin, refetchInterval: 3000, refetchOnWindowFocus: true, retry: false });
  const activity = trpc.admin.activity.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const watchStats = trpc.admin.watchStats.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const allVideos = trpc.admin.videos.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const adjustPoints = trpc.admin.adjustPoints.useMutation({
    onSuccess: (_updatedUser, variables) => {
      setBalanceInputs((current) => ({ ...current, [variables.openId]: "" }));
      setBalanceStatus({ type: "success", message: `${variables.amount > 0 ? "Balance added" : "Balance deducted"} successfully.` });
      void users.refetch();
      void me.refetch();
    },
    onError: (error) => setBalanceStatus({ type: "error", message: error.message || "Balance update করা যায়নি।" }),
  });
  const setBanned = trpc.admin.setBanned.useMutation({ onSuccess: () => users.refetch() });
  const setVisibility = trpc.admin.setVisibility.useMutation({ onSuccess: () => allVideos.refetch() });
  const setFeatured = trpc.admin.setFeatured.useMutation({ onSuccess: () => allVideos.refetch() });
  const setVideoAccess = trpc.admin.setVideoAccess.useMutation({ onSuccess: () => allVideos.refetch() });
  const deleteVideo = trpc.admin.deleteVideo.useMutation({ onSuccess: () => allVideos.refetch() });
  const restoreVideo = trpc.admin.restoreVideo.useMutation({ onSuccess: () => allVideos.refetch() });
  const captchaRewardVisibility = trpc.admin.captchaRewardVisibility.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const setCaptchaRewardVisibility = trpc.admin.setCaptchaRewardVisibility.useMutation({ onSuccess: () => captchaRewardVisibility.refetch() });
  const setCaptchaDailyLimit = trpc.admin.setCaptchaDailyLimit.useMutation({ onSuccess: (settings) => { setCaptchaLimitInput(String(settings.captchaDailyLimit)); setCaptchaLimitStatus(`Daily Captcha limit এখন ${settings.captchaDailyLimit}টি।`); void captchaRewardVisibility.refetch(); }, onError: (error) => setCaptchaLimitStatus(error.message) });
  const setCaptchaRewardPoints = trpc.admin.setCaptchaRewardPoints.useMutation({ onSuccess: (settings) => { setCaptchaRewardInput(String(settings.captchaRewardPoints)); setCaptchaRewardStatus(`প্রতি Captcha reward এখন ${settings.captchaRewardPoints} পয়সা।`); void captchaRewardVisibility.refetch(); }, onError: (error) => setCaptchaRewardStatus(error.message) });
  const setPremiumOnly = trpc.admin.setPremiumOnly.useMutation({ onSuccess: () => captchaRewardVisibility.refetch(), onError: (error) => toast.error(error.message) });
  const sendNotification = trpc.admin.sendNotification.useMutation({ onSuccess: () => { toast.success(notificationSchedule ? "Notification schedule হয়েছে।" : "Notification পাঠানো হয়েছে।"); setNotificationTitle(""); setNotificationMessage(""); setNotificationSchedule(""); }, onError: (error) => toast.error(error.message || "Notification পাঠানো যায়নি।") });
  const walletRequests = trpc.admin.walletRequests.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const monetizationInvoices = trpc.admin.monetizationInvoices.useQuery(undefined, { enabled: isAdmin, refetchInterval: 5000, retry: false });
  const reviewWalletRequest = trpc.admin.reviewWalletRequest.useMutation({ onSuccess: () => walletRequests.refetch() });
  const approveMembership = trpc.admin.approveMembership.useMutation({ onSuccess: () => monetizationInvoices.refetch(), onError: (error) => toast.error(error.message) });

  useEffect(() => {
    if (!isAdmin) return;
    heartbeat.mutate();
    const sendHeartbeat = () => heartbeat.mutate(undefined);
    sendHeartbeat();
    const timer = window.setInterval(sendHeartbeat, 10000);
    const refreshClock = window.setInterval(() => setNow(Date.now()), 5000);
    const refreshHeartbeat = () => sendHeartbeat();
    window.addEventListener("focus", refreshHeartbeat);
    document.addEventListener("visibilitychange", refreshHeartbeat);
    return () => { window.clearInterval(timer); window.clearInterval(refreshClock); window.removeEventListener("focus", refreshHeartbeat); document.removeEventListener("visibilitychange", refreshHeartbeat); };
  }, [isAdmin]);

  useEffect(() => {
    if (balanceStatus) (balanceStatus.type === "error" ? toast.error : toast.success)(balanceStatus.message);
  }, [balanceStatus]);
  useEffect(() => {
    if (captchaLimitStatus) toast.success(captchaLimitStatus);
  }, [captchaLimitStatus]);
  useEffect(() => {
    if (captchaRewardStatus) toast.success(captchaRewardStatus);
  }, [captchaRewardStatus]);

  useEffect(() => {
    if (captchaRewardVisibility.data?.captchaDailyLimit) setCaptchaLimitInput(String(captchaRewardVisibility.data.captchaDailyLimit));
    if (captchaRewardVisibility.data?.captchaRewardPoints) setCaptchaRewardInput(String(captchaRewardVisibility.data.captchaRewardPoints));
  }, [captchaRewardVisibility.data?.captchaDailyLimit]);

  function submitEmail(event: React.FormEvent) {
    event.preventDefault();
    if (email.trim().toLowerCase() !== ADMIN_EMAIL) {
      setStatus({ type: "error", message: "এই Gmail address অনুমোদিত নয়।" });
      return;
    }
    try { sessionStorage.setItem("xvidos-admin-email", ADMIN_EMAIL); } catch {}
    startLogin("/admin");
  }

  async function addVideo(file: File) {
    if (!file.type.startsWith("video/")) return setStatus({ type: "error", message: "শুধু video file নির্বাচন করুন।" });
    if (file.size > MAX_VIDEO_BYTES) return setStatus({ type: "error", message: "ভিডিওর সর্বোচ্চ আকার 50 MB।" });
    setStatus({ type: "uploading", percent: 0 });
    try {
      const init = await createUpload.mutateAsync({ fileName: file.name, mimeType: file.type, sizeBytes: file.size });
      const stored = await uploadWithProgress(file, init.uploadUrl, (percent) => setStatus({ type: "uploading", percent }));
      await complete.mutateAsync({ storageKey: stored.key, fileName: file.name, mimeType: file.type, sizeBytes: file.size, durationSeconds: await getDuration(file), qualityVariants: stored.qualityVariants, category: videoCategory, tags: videoTags });
      setStatus({ type: "success", message: "ভিডিও homepage gallery-তে যোগ হয়েছে।", percent: 100 });
    } catch (error) {
      setStatus({ type: "error", message: error instanceof Error ? error.message : "ভিডিও যোগ করা যায়নি।" });
    }
  }

  if (me.isLoading) return <div className="admin-page"><Loader2 className="spin" size={25} /></div>;
  if (!isAdmin) return (
    <div className="admin-page"><div className="admin-card">
      <Link href="/" className="back-link"><ArrowLeft size={15} /> Homepage</Link>
      <div className="admin-icon"><ShieldCheck size={25} /></div><p className="eyebrow">XV / ADMIN ACCESS</p><h1>Admin panel</h1>
      <p className="admin-copy">শুধু অনুমোদিত Gmail দিয়ে submit করুন। এরপর Google/Manus account verification সম্পন্ন হলে panel খুলবে।</p>
      <form onSubmit={submitEmail} className="admin-form"><label htmlFor="admin-email">অনুমোদিত Gmail address</label><input id="admin-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@gmail.com" required /><Button type="submit"><ShieldCheck size={16} /> Submit & verify</Button></form>
      {status.type === "error" && <p className="admin-error"><AlertCircle size={15} /> {status.message}</p>}
    </div></div>
  );

  return <div className="admin-page"><div className="admin-card admin-card-wide">
    <div className="admin-top"><Link href="/" className="back-link"><ArrowLeft size={15} /> Homepage</Link><button className="admin-logout" onClick={() => logout.mutate()}><LogOut size={14} /> Sign out</button></div>
    <div className="admin-icon"><CloudUpload size={25} /></div><p className="eyebrow">XV / ADMIN ACCESS GRANTED</p><h1>ভিডিও যোগ করুন</h1><p className="admin-copy">এই panel থেকে যোগ করা প্রতিটি আসল ভিডিও homepage gallery-তে দেখা যাবে। কোনো filter, frame বা crop যোগ হবে না।</p>
    <div className="admin-meta-fields"><input value={videoCategory} onChange={(event) => setVideoCategory(event.target.value)} placeholder="Category (যেমন Music)" /><input value={videoTags} onChange={(event) => setVideoTags(event.target.value)} placeholder="Tags comma দিয়ে লিখুন" /></div><div className="admin-drop" onClick={() => inputRef.current?.click()}><FileVideo size={30} /><strong>ভিডিও বাছাই করুন</strong><span>MP4 · MOV · WEBM / সর্বোচ্চ 50 MB</span><input ref={inputRef} className="sr-only" type="file" accept="video/*" onChange={(event) => { if (event.target.files?.[0]) void addVideo(event.target.files[0]); event.currentTarget.value = ""; }} /></div>
    {status.type === "uploading" && <div className="admin-progress"><span style={{ width: `${status.percent ?? 0}%` }} /></div>}
    {status.type === "success" && <p className="admin-success"><Check size={16} /> {status.message}</p>}
    {status.type === "error" && <p className="admin-error"><AlertCircle size={15} /> {status.message}</p>}
    <div className="moderation-heading"><span className="eyebrow">PENDING USER VIDEOS</span><strong>{pending.data?.length ?? 0}</strong></div>
    {pending.isLoading && <div className="moderation-empty"><Loader2 className="spin" size={18} /> queue লোড হচ্ছে...</div>}
    {!pending.isLoading && pending.data?.length === 0 && <div className="moderation-empty">কোনো pending video নেই।</div>}
    <div className="moderation-list">{pending.data?.map((video) => <article className="moderation-item" key={video.id}>
      <video src={video.storageUrl} controls playsInline preload="metadata" crossOrigin="anonymous" />
      <div className="moderation-info"><strong>{video.title}</strong><span>{video.fileName} · {(video.sizeBytes / (1024 * 1024)).toFixed(1)} MB</span></div>
      <div className="moderation-actions"><Button className="confirm-button" disabled={approve.isPending || reject.isPending} onClick={() => approve.mutate({ id: video.id })}><Check size={15} /> Confirm</Button><Button variant="outline" className="reject-button" disabled={approve.isPending || reject.isPending} onClick={() => reject.mutate({ id: video.id })}>Reject</Button></div>
    </article>)}</div>
    <div className="moderation-heading"><span className="eyebrow">USER PRESENCE & BALANCE</span><strong>{users.data?.length ?? 0}</strong></div>
    <label className="admin-user-search"><Search size={15} /><input value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder="Gmail, name বা open ID দিয়ে user খুঁজুন..." aria-label="Search users" /></label>
    {balanceStatus?.type === "error" && <p className="admin-error"><AlertCircle size={15} /> {balanceStatus.message}</p>}
    {balanceStatus?.type === "success" && <p className="admin-success"><Check size={16} /> {balanceStatus.message}</p>}
    <div className="user-list">{users.data?.map((user) => { const online = now - new Date(user.lastSeenAt).getTime() < 45000; const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(now); const claimsToday = user.captchaClaimDate === today ? user.captchaClaims : 0; const captchaLimit = captchaRewardVisibility.data?.captchaDailyLimit ?? 20; const amount = Number(balanceInputs[user.openId] || 0); const pointsAmount = Number.isFinite(amount) ? Math.round(amount * 100) : 0; const canAdjust = pointsAmount > 0 && pointsAmount <= 10000000 && !adjustPoints.isPending; return <article className="user-row" key={user.openId}>
      <div className={`presence-dot ${online ? "online" : "offline"}`} /><div className="user-identity"><strong>{user.name || "Unnamed user"}</strong><span>{user.email || user.openId}</span><em className={online ? "presence-label online-label" : "presence-label offline-label"}>{online ? "ONLINE NOW" : "OFFLINE"}</em></div><span className={`presence-status-button ${online ? "is-online" : "is-offline"}`} aria-label={`${user.name || user.email || "User"} is ${online ? "online" : "offline"}`}><i />{online ? "ONLINE" : "OFFLINE"}</span><span className="captcha-count" title="আজকের Captcha পূরণ"><b>{claimsToday}</b>/{captchaLimit}<small>CAPTCHA TODAY</small></span><span className="user-points">৳{(user.points / 100).toFixed(2)}<small>{user.points} pts</small></span><div className="user-controls"><input className="balance-input" inputMode="decimal" placeholder="BDT" value={balanceInputs[user.openId] ?? ""} onChange={(event) => setBalanceInputs((current) => ({ ...current, [user.openId]: event.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1") }))} /><button disabled={!canAdjust} onClick={() => adjustPoints.mutate({ openId: user.openId, amount: pointsAmount })}>Add</button><button disabled={!canAdjust} onClick={() => adjustPoints.mutate({ openId: user.openId, amount: -pointsAmount })}>Deduct</button><button className={user.banned ? "unban" : "ban"} onClick={() => setBanned.mutate({ openId: user.openId, banned: !user.banned })}>{user.banned ? "Unban" : "Ban"}</button></div>
    </article>; })}</div>
    <div className="moderation-heading"><span className="eyebrow">DAILY CAPTCHA REWARD</span><strong>{captchaRewardVisibility.data?.captchaRewardVisible ? "VISIBLE" : "HIDDEN"}</strong></div>
    <div className="settings-row"><div><strong>User reward section</strong><span>Homepage থেকে Daily Captcha Reward block hide/unhide করুন।</span></div><button className={`visibility-toggle ${captchaRewardVisibility.data?.captchaRewardVisible ? "is-visible" : "is-hidden"}`} onClick={() => setCaptchaRewardVisibility.mutate({ visible: !Boolean(captchaRewardVisibility.data?.captchaRewardVisible) })}><span /> {captchaRewardVisibility.data?.captchaRewardVisible ? "Visible" : "Hidden"}</button></div>
    <div className="settings-row"><div><strong>Daily Captcha limit</strong><span>Default ২০টি। এখানে limit বাড়িয়ে বা নতুন limit দিয়ে replace করতে পারবেন (সর্বোচ্চ ১০০০)।</span></div><div className="captcha-limit-control"><input className="balance-input" type="number" min="1" max="1000" value={captchaLimitInput} onChange={(event) => setCaptchaLimitInput(event.target.value)} /><button disabled={setCaptchaDailyLimit.isPending} onClick={() => { const limit = Number(captchaLimitInput); if (Number.isInteger(limit) && limit >= 1 && limit <= 1000) setCaptchaDailyLimit.mutate({ limit }); else setCaptchaLimitStatus("Limit ১ থেকে ১০০০-এর মধ্যে দিন।"); }}>Replace limit</button></div></div>
    {captchaLimitStatus && <p className={captchaLimitStatus.includes("এখন") ? "admin-success" : "admin-error"}>{captchaLimitStatus}</p>}
    <div className="settings-row"><div><strong>Reward per Captcha</strong><span>প্রতি সঠিক Captcha-তে কত পয়সা পাবেন সেটি দিন। Default ১০ পয়সা; সর্বোচ্চ ১০,০০০ পয়সা।</span></div><div className="captcha-limit-control"><input className="balance-input" type="number" min="1" max="10000" value={captchaRewardInput} onChange={(event) => setCaptchaRewardInput(event.target.value)} /><span className="paisa-suffix">পয়সা</span><button disabled={setCaptchaRewardPoints.isPending} onClick={() => { const points = Number(captchaRewardInput); if (Number.isInteger(points) && points >= 1 && points <= 10000) setCaptchaRewardPoints.mutate({ points }); else setCaptchaRewardStatus("Reward ১ থেকে ১০,০০০ পয়সার মধ্যে দিন।"); }}>Replace reward</button></div></div>
    {captchaRewardStatus && <p className={captchaRewardStatus.includes("এখন") ? "admin-success" : "admin-error"}>{captchaRewardStatus}</p>}
    <div className="moderation-heading"><span className="eyebrow">BROADCAST NOTIFICATION</span><strong>ALL USERS</strong></div>
    <div className="notification-composer"><input value={notificationTitle} onChange={(event) => setNotificationTitle(event.target.value)} maxLength={160} placeholder="Notification title" /><textarea value={notificationMessage} onChange={(event) => setNotificationMessage(event.target.value)} maxLength={2000} rows={3} placeholder="সব user-এর কাছে যে message যাবে..." /><div className="notification-admin-controls"><select value={notificationCategory} onChange={(event) => setNotificationCategory(event.target.value as typeof notificationCategory)}><option value="broadcast">Broadcast</option><option value="new_video">New video</option><option value="wallet">Wallet</option><option value="security">Security</option><option value="system">System</option></select><select value={notificationRecipient} onChange={(event) => setNotificationRecipient(event.target.value)}><option value="">All users</option>{users.data?.map((user) => <option key={user.openId} value={user.openId}>{user.email || user.openId}</option>)}</select><input type="datetime-local" value={notificationSchedule} onChange={(event) => setNotificationSchedule(event.target.value)} aria-label="Schedule notification" /></div><button disabled={sendNotification.isPending || !notificationTitle.trim() || !notificationMessage.trim()} onClick={() => sendNotification.mutate({ title: notificationTitle.trim(), message: notificationMessage.trim(), category: notificationCategory, recipientOpenId: notificationRecipient || null, scheduledFor: notificationSchedule ? new Date(notificationSchedule).toISOString() : null })}>{notificationSchedule ? "Schedule notification" : notificationRecipient ? "Send to selected user" : "Send to everyone"}</button></div>
    <div className="moderation-heading"><span className="eyebrow">VIDEO WATCH TIME</span><strong>{watchStats.data?.length ?? 0}</strong></div>
    <div className="watch-list">{watchStats.data?.length ? watchStats.data.map((watch) => <article className="watch-row" key={watch.id}><div><span className="watch-label">USER</span><strong>{watch.userName || "Unnamed user"}</strong></div><div><span className="watch-label">GMAIL</span><strong>{watch.userEmail || watch.userOpenId}</strong></div><div><span className="watch-label">VIDEO</span><strong>{watch.videoTitle || "Unknown video"}</strong></div><div><span className="watch-label">UNIT CODE / FILE</span><strong>UNIT XV-{String(watch.videoId).padStart(6, "0")} · {watch.videoFileName || "—"}</strong></div><div className="watch-time"><span className="watch-label">WATCHED</span><strong>{watch.secondsWatched}s · position {watch.lastPositionSeconds}s</strong></div></article>) : <div className="moderation-empty">কোনো signed-in user video দেখেনি।</div>}</div>
    <div className="moderation-heading"><span className="eyebrow">MASTER VIDEO SWITCH</span><strong>{allVideos.data?.length ?? 0}</strong></div>
    <div className="settings-row premium-gate-row"><div><strong>Premium video gate</strong><span>ON করলে paid/premium video active subscription ছাড়া দেখা বা download করা যাবে না। OFF করলে paid video public হবে।</span></div><button className={`visibility-toggle ${captchaRewardVisibility.data?.premiumOnly ? "is-visible" : "is-hidden"}`} disabled={setPremiumOnly.isPending} onClick={() => setPremiumOnly.mutate({ enabled: !Boolean(captchaRewardVisibility.data?.premiumOnly) })}><span /> {captchaRewardVisibility.data?.premiumOnly ? "PREMIUM ON" : "PREMIUM OFF"}</button></div>
    <div className="visibility-list">{allVideos.data?.map((video) => <article className="visibility-row" key={video.id}><div><strong>{video.title}</strong><span>{video.category} · {video.tags || "no tags"} · {video.status} · {video.deletedAt ? "TRASHED" : video.visibility} · {video.viewCount} views</span></div><div className="video-admin-actions"><button className={`visibility-toggle ${video.accessType === "paid" ? "is-visible" : "is-hidden"}`} onClick={() => setVideoAccess.mutate({ id: video.id, accessType: video.accessType === "paid" ? "free" : "paid", pricePoints: video.pricePoints || 1000 })}><span /> {video.accessType === "paid" ? `Premium ৳${(video.pricePoints / 100).toFixed(2)}` : "Make premium"}</button><button className={`visibility-toggle ${video.featured ? "is-visible" : "is-hidden"}`} onClick={() => setFeatured.mutate({ id: video.id, featured: !Boolean(video.featured) })}><span /> {video.featured ? "Featured" : "Feature"}</button>{video.deletedAt ? <button className="confirm-button" onClick={() => restoreVideo.mutate({ id: video.id })}>Restore</button> : <button className="reject-button" onClick={() => deleteVideo.mutate({ id: video.id })}>Move to trash</button>}<button className={`visibility-toggle ${video.visibility === "visible" && !video.deletedAt ? "is-visible" : "is-hidden"}`} onClick={() => setVisibility.mutate({ id: video.id, visibility: video.visibility === "visible" ? "hidden" : "visible" })}><span /> {video.visibility === "visible" ? "Visible" : "Hidden"}</button></div></article>)}</div>
    <div className="moderation-heading"><span className="eyebrow">ADMIN ACTIVITY LOG</span><strong><History size={14} /> {activity.data?.length ?? 0}</strong></div>
    <div className="admin-activity-list">{activity.data?.map((entry) => <article className="admin-activity-row" key={entry.id}><span className="activity-dot" /><div><strong>{entry.action.replaceAll("_", " ")}</strong><span>{entry.details || "Admin action"}{entry.targetOpenId ? ` · target ${entry.targetOpenId}` : ""}</span></div><time>{new Date(entry.createdAt).toLocaleString("bn-BD")}</time></article>)}</div>
    <div className="moderation-heading"><span className="eyebrow">MONETIZATION / MEMBERSHIP REQUESTS</span><strong>{monetizationInvoices.data?.length ?? 0}</strong></div>
    <div className="wallet-request-list">{monetizationInvoices.data?.map((invoice) => <article className="wallet-request-row" key={invoice.id}><div className="wallet-request-main"><strong>{invoice.itemType} · ৳{(invoice.amountPoints / 100).toFixed(2)}</strong><span>{invoice.invoiceNumber} · {invoice.userOpenId}</span></div><button className="confirm-button" disabled={approveMembership.isPending} onClick={() => approveMembership.mutate({ invoiceId: invoice.id })}>Approve membership</button></article>)}</div>
    <div className="moderation-heading"><span className="eyebrow">WALLET REQUESTS</span><strong>{walletRequests.data?.filter((request) => request.status === "pending").length ?? 0}</strong></div>
    <div className="wallet-request-list">{walletRequests.data?.map((request) => <article className="wallet-request-row" key={request.id}><div className="wallet-request-main"><strong>{request.type === "recharge" ? "Recharge" : "Withdraw"} · ৳{(request.amountPoints / 100).toFixed(2)} ({request.amountPoints} pts)</strong><span>{request.userName || "Unnamed"} · {request.userEmail || request.userOpenId}</span><span>{request.phoneNumber} · {request.operator || request.method || "—"}</span>{request.adminNote && <small className="admin-note">Note: {request.adminNote}</small>}</div><span className={`request-status status-${request.status}`}>{request.status}</span>{request.status === "pending" && <div className="request-actions"><input className="review-note-input" value={reviewNotes[request.id] ?? ""} maxLength={500} onChange={(event) => setReviewNotes((current) => ({ ...current, [request.id]: event.target.value }))} placeholder="Approval note (optional)" /><button className="confirm-button" onClick={() => reviewWalletRequest.mutate({ id: request.id, status: "approved", adminNote: reviewNotes[request.id] || undefined })}>Approve</button><button className="reject-button" onClick={() => reviewWalletRequest.mutate({ id: request.id, status: "rejected", adminNote: reviewNotes[request.id] || undefined })}>Reject</button></div>}</article>)}</div>
  </div></div>;
}
