import {
  AlertCircle,
  ArrowUpRight,
  Bell,
  Check,
  Clapperboard,
  CloudUpload,
  FileVideo,
  HardDrive,
  Heart,
  Loader2,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Upload,
  Volume2,
  Moon,
  Sun,
  UserRound,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { toast } from "sonner";

type VideoRecord = {
  id: number;
  title: string;
  fileName: string;
  storageKey: string;
  storageUrl: string;
  qualityVariants: string | null;
  mimeType: string;
  sizeBytes: number;
  durationSeconds: number | null;
  createdAt: Date;
  category: string;
  tags: string | null;
  viewCount: number;
  likeCount: number;
  favoriteCount: number;
  featured: number;
};

type UploadState = {
  fileName: string;
  previewUrl: string;
  percent: number;
  status: "uploading" | "success" | "error";
  message?: string;
};

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };
type QualityVariant = { label: string; url: string; height: number };
const QUALITY_LEVELS = ["144p", "240p", "360p", "480p", "720p", "1080p"];

const MAX_VIDEO_BYTES = 50 * 1024 * 1024;
const POINTS_PER_BDT = 100;

function parseQualityVariants(raw: string | null | undefined): QualityVariant[] {
  if (!raw) return [];
  try { const parsed = JSON.parse(raw) as unknown; return Array.isArray(parsed) ? parsed.filter((item): item is QualityVariant => Boolean(item && typeof item === "object" && "label" in item && "url" in item && "height" in item)) : []; } catch { return []; }
}

function formatBdt(points: number) {
  return `৳${(points / POINTS_PER_BDT).toFixed(2)}`;
}

function base64ToUint8Array(value: string) {
  const padding = "=".repeat((4 - (value.length % 4)) % 4);
  const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
  return Uint8Array.from(atob(base64), (character) => character.charCodeAt(0));
}

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(bytes > 100 * 1024 * 1024 ? 0 : 1)} MB`;
}

function formatDate(value: Date | string) {
  return new Intl.DateTimeFormat("bn-BD", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}

function readDuration(file: File) {
  return new Promise<number | null>((resolve) => {
    const url = URL.createObjectURL(file);
    const probe = document.createElement("video");
    probe.preload = "metadata";
    probe.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(probe.duration) ? Math.round(probe.duration) : null);
    };
    probe.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(null);
    };
    probe.src = url;
  });
}

function uploadWithProgress(file: File, uploadUrl: string, onProgress: (percent: number) => void) {
  return new Promise<{ key: string; url: string; qualityVariants: QualityVariant[] }>((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("PUT", uploadUrl);
    request.setRequestHeader("X-Upload-File-Name", encodeURIComponent(file.name));
    request.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    request.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.min(99, Math.round((event.loaded / event.total) * 100)));
    };
    request.onload = () => {
      if (request.status >= 200 && request.status < 300) {
        try {
          const result = JSON.parse(request.responseText) as { key?: string; url?: string; qualityVariants?: QualityVariant[] };
          if (!result.key || !result.url) throw new Error("Upload response was incomplete");
          resolve({ key: result.key, url: result.url, qualityVariants: result.qualityVariants ?? [] });
        } catch (error) {
          reject(error instanceof Error ? error : new Error("Upload response was invalid"));
        }
      }
      else {
        let message = `Storage upload failed (${request.status})`;
        try { const result = JSON.parse(request.responseText) as { error?: string }; if (result.error) message = result.error; } catch {}
        reject(new Error(message));
      }
    };
    request.onerror = () => reject(new Error("Network connection interrupted"));
    request.onabort = () => reject(new Error("Upload cancelled"));
    request.send(file);
  });
}

export default function Home() {
  const [theme, setTheme] = useState<"dark" | "light">(() => (typeof window !== "undefined" && localStorage.getItem("xvidos-theme") === "light" ? "light" : "dark"));
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [walletCenterOpen, setWalletCenterOpen] = useState(false);
  const [notificationCenterOpen, setNotificationCenterOpen] = useState(false);
  const [notificationCategory, setNotificationCategory] = useState<"all" | "broadcast" | "new_video" | "wallet" | "security">("all");
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | "unsupported">("unsupported");
  const [phoneAlertsEnabled, setPhoneAlertsEnabled] = useState(false);
  const [selectedQuality, setSelectedQuality] = useState<Record<number, string>>({});
  const lastNotificationId = useRef<number | null>(null);
  const previousWalletStatuses = useRef<Record<number, string>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const retryFileRef = useRef<File | null>(null);
  const watchMarkers = useRef<Record<number, number>>({});
  const viewedVideos = useRef<Set<number>>(new Set());
  const [search, setSearch] = useState("");
  const [sortMode, setSortMode] = useState<"newest" | "oldest" | "most-watched" | "recently-watched">("newest");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [upload, setUpload] = useState<UploadState | null>(null);
  const [uploadCategory, setUploadCategory] = useState("General");
  const [uploadTags, setUploadTags] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [captchaMessage, setCaptchaMessage] = useState<string | null>(null);
  const [walletPanel, setWalletPanel] = useState<"withdraw" | "recharge" | null>(null);
  const [walletPhone, setWalletPhone] = useState("");
  const [walletAmount, setWalletAmount] = useState("");
  const [walletOperator, setWalletOperator] = useState("");
  const [walletMethod, setWalletMethod] = useState("");
  const { data: sessionUser, refetch: refetchSession } = trpc.auth.me.useQuery(undefined, { retry: false, refetchInterval: 2000, refetchOnWindowFocus: true });
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => { setCaptchaMessage("আপনি logout করেছেন। আবার login করলে balance access করা যাবে।"); void refetchSession(); } });
  useEffect(() => {
    document.documentElement.classList.toggle("theme-light", theme === "light");
    localStorage.setItem("xvidos-theme", theme);
  }, [theme]);
  const latestNotification = trpc.notifications.latest.useQuery(undefined, { refetchInterval: 2000, retry: false });
  const pushPublicKey = trpc.notifications.publicKey.useQuery(undefined, { retry: false, staleTime: Infinity });
  const subscribePush = trpc.notifications.subscribe.useMutation();
  const unsubscribePush = trpc.notifications.unsubscribe.useMutation();
  const notificationHistory = trpc.notifications.history.useQuery({ category: notificationCategory }, { enabled: Boolean(sessionUser), refetchInterval: 2000, retry: false });
  const notificationPreferences = trpc.notifications.preferences.useQuery(undefined, { enabled: Boolean(sessionUser), retry: false });
  const markNotificationRead = trpc.notifications.markRead.useMutation({ onSuccess: () => notificationHistory.refetch() });
  const setNotificationPreferences = trpc.notifications.setPreferences.useMutation({ onSuccess: () => notificationPreferences.refetch() });
  const walletCenter = trpc.walletCenter.summary.useQuery(undefined, { enabled: Boolean(sessionUser), refetchInterval: 2000, retry: false });
  const monetizationCatalog = trpc.monetization.catalog.useQuery(undefined, { staleTime: 60000, retry: false });
  const monetizationMe = trpc.monetization.me.useQuery(undefined, { enabled: Boolean(sessionUser), refetchInterval: 10000, retry: false });
  const requestMembership = trpc.monetization.requestMembership.useMutation({ onSuccess: (result) => toast.success(`${result.message} Invoice: ${result.invoiceNumber || "pending"}`), onError: (error) => toast.error(error.message) });
  useEffect(() => {
    if (!notificationCenterOpen || !notificationHistory.data?.length) return;
    const unread = notificationHistory.data.filter((item) => !item.readAt);
    if (unread.length) void Promise.all(unread.map((item) => markNotificationRead.mutateAsync({ id: item.id })));
  }, [notificationCenterOpen, notificationHistory.data]);
  useEffect(() => {
    const captureInstallPrompt = (event: Event) => { event.preventDefault(); setInstallPrompt(event as InstallPromptEvent); };
    window.addEventListener("beforeinstallprompt", captureInstallPrompt);
    return () => window.removeEventListener("beforeinstallprompt", captureInstallPrompt);
  }, []);
  useEffect(() => {
    if (!captchaMessage) return;
    const isError = /incorrect|failed|error|limit|ভুল|ব্যর্থ|বন্ধ/i.test(captchaMessage);
    (isError ? toast.error : toast.success)(captchaMessage);
  }, [captchaMessage]);
  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      const permission = window.Notification.permission;
      setNotificationPermission(permission);
      if (permission === "granted") {
        setPhoneAlertsEnabled(true);
        try { localStorage.setItem("xvidos-phone-alerts", "on"); } catch {}
      }
    }
  }, []);
  useEffect(() => {
    const isInstalledApp = window.matchMedia?.("(display-mode: standalone)").matches || (window.navigator as Navigator & { standalone?: boolean }).standalone === true;
    if (!isInstalledApp || !("Notification" in window) || window.Notification.permission !== "default") return;
    let alreadyPrompted = false;
    try { alreadyPrompted = localStorage.getItem("xvidos-notification-prompted") === "yes"; } catch {}
    if (alreadyPrompted) return;
    const timer = window.setTimeout(() => {
      void window.Notification.requestPermission().then((permission) => {
        try { localStorage.setItem("xvidos-notification-prompted", "yes"); } catch {}
        setNotificationPermission(permission);
        if (permission === "granted") {
          setPhoneAlertsEnabled(true);
          try { localStorage.setItem("xvidos-phone-alerts", "on"); } catch {}
          toast.success("xvidos app notification চালু হয়েছে।");
        }
      });
    }, 700);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (!phoneAlertsEnabled || notificationPermission !== "granted" || !pushPublicKey.data || !("serviceWorker" in navigator) || !("PushManager" in window)) return;
    let cancelled = false;
    void navigator.serviceWorker.ready.then(async (registration) => {
      if (cancelled) return;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: base64ToUint8Array(pushPublicKey.data) });
      const json = subscription.toJSON();
      if (json.endpoint && json.keys?.p256dh && json.keys?.auth) await subscribePush.mutateAsync({ endpoint: json.endpoint, keys: { p256dh: json.keys.p256dh, auth: json.keys.auth } });
    }).catch((error) => console.warn("[WebPush] Subscription failed:", error));
    return () => { cancelled = true; };
  }, [phoneAlertsEnabled, notificationPermission, pushPublicKey.data, sessionUser?.openId]);
  useEffect(() => {
    const notification = latestNotification.data;
    if (!notification) return;
    const previousId = lastNotificationId.current;
    lastNotificationId.current = notification.id;
    if (previousId !== null && notification.id > previousId) {
      toast(notification.title, { description: notification.message, duration: 9000 });
      if (phoneAlertsEnabled && typeof window !== "undefined" && "Notification" in window && window.Notification.permission === "granted") {
        void navigator.serviceWorker?.ready.then((registration) => registration.showNotification(notification.title, { body: notification.message, icon: "/xvidos-icon.svg", tag: `xvidos-broadcast-${notification.id}` })).catch(() => new window.Notification(notification.title, { body: notification.message, icon: "/xvidos-icon.svg" }));
      }
    }
  }, [latestNotification.data, phoneAlertsEnabled]);
  useEffect(() => {
    const transactions = walletCenter.data?.transactions;
    if (!transactions) return;
    let changed = false;
    for (const transaction of transactions) {
      const previous = previousWalletStatuses.current[transaction.id];
      if (previous && previous !== transaction.status) {
        changed = true;
        if (transaction.status === "approved") toast.success(`আপনার ${transaction.type} request approved হয়েছে।`);
        if (transaction.status === "rejected") toast.error(`আপনার ${transaction.type} request rejected হয়েছে; reserved balance ফেরত দেওয়া হয়েছে।`);
      }
      previousWalletStatuses.current[transaction.id] = transaction.status;
    }
    if (changed) void refetchSession();
  }, [walletCenter.data, refetchSession]);
  const heartbeat = trpc.auth.heartbeat.useMutation();
  const rewardSettings = trpc.settings.public.useQuery(undefined, { refetchInterval: 5000, retry: false });
  const captcha = trpc.captcha.challenge.useQuery(undefined, { refetchOnWindowFocus: false });
  const verifyCaptcha = trpc.captcha.verify.useMutation({ onSuccess: async (result) => { sessionStorage.removeItem("xvidos-pending-captcha"); setCaptchaAnswer(""); setCaptchaMessage(`সঠিক Captcha: +${result.pointsAwarded} points (${formatBdt(result.pointsAwarded)}) যোগ হয়েছে। আজ ${result.claimsToday}/${result.dailyLimit}; balance ${formatBdt(result.balance)}`); await Promise.all([captcha.refetch(), refetchSession()]); }, onError: (error) => { sessionStorage.removeItem("xvidos-pending-captcha"); setCaptchaMessage(error.message); } });
  const createWalletRequest = trpc.wallet.createRequest.useMutation({ onSuccess: async () => { setCaptchaMessage("Request জমা হয়েছে এবং requested amount আপনার balance থেকে reserve করা হয়েছে। Reject হলে amount ফেরত যাবে।"); setWalletPhone(""); setWalletAmount(""); await refetchSession(); }, onError: (error) => setCaptchaMessage(error.message) });
  const { data: videos = [], isLoading, isError, refetch } = trpc.videos.list.useQuery(undefined, { retry: 1, refetchInterval: 2000 });
  const createUpload = trpc.videos.createUpload.useMutation();
  const completeUpload = trpc.videos.complete.useMutation();
  const recordWatch = trpc.videos.recordWatch.useMutation();
  const recordView = trpc.videos.recordView.useMutation();
  const collections = trpc.videos.collections.useQuery(undefined, { enabled: Boolean(sessionUser), retry: false });
  const likeVideo = trpc.videos.like.useMutation({ onSuccess: () => collections.refetch() });
  const favoriteVideo = trpc.videos.favorite.useMutation({ onSuccess: () => collections.refetch() });
  const reportVideo = trpc.videos.report.useMutation({ onSuccess: () => toast.success("Video report জমা হয়েছে।") });

  useEffect(() => {
    if (!sessionUser || verifyCaptcha.isPending) return;
    const saved = sessionStorage.getItem("xvidos-pending-captcha");
    if (!saved) return;
    try {
      const pending = JSON.parse(saved) as { token: string; answer: string };
      if (pending.token && /^[a-z0-9]{6}$/i.test(pending.answer)) {
        setCaptchaMessage("Gmail login সম্পন্ন হয়েছে—আপনার Captcha যাচাই হচ্ছে...");
        verifyCaptcha.mutate(pending);
      } else sessionStorage.removeItem("xvidos-pending-captcha");
    } catch {
      sessionStorage.removeItem("xvidos-pending-captcha");
    }
  }, [sessionUser, verifyCaptcha.isPending]);

  useEffect(() => {
    if (!sessionUser) return;
    const sendHeartbeat = () => heartbeat.mutate(undefined);
    sendHeartbeat();
    const timer = window.setInterval(sendHeartbeat, 10000);
    const refreshHeartbeat = () => sendHeartbeat();
    window.addEventListener("focus", refreshHeartbeat);
    document.addEventListener("visibilitychange", refreshHeartbeat);
    return () => { window.clearInterval(timer); window.removeEventListener("focus", refreshHeartbeat); document.removeEventListener("visibilitychange", refreshHeartbeat); };
  }, [sessionUser?.openId]);

  const filteredVideos = useMemo(() => {
    const term = search.trim().toLowerCase();
    const result = (videos as VideoRecord[]).filter((video) => {
      const haystack = `${video.title} ${video.fileName} ${video.category} ${video.tags ?? ""}`.toLowerCase();
      return (!term || haystack.includes(term)) && (categoryFilter === "all" || video.category === categoryFilter);
    });
    const recentOrder = new Map((collections.data?.recent ?? []).map((entry, index) => [entry.videoId, index]));
    return result.sort((a, b) => sortMode === "oldest" ? new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime() : sortMode === "most-watched" ? b.viewCount - a.viewCount : sortMode === "recently-watched" ? (recentOrder.get(a.id) ?? 999) - (recentOrder.get(b.id) ?? 999) : (Number(b.featured) - Number(a.featured)) || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [search, categoryFilter, sortMode, videos, collections.data?.recent]);
  const categories = useMemo(() => ["all", ...Array.from(new Set((videos as VideoRecord[]).map((video) => video.category || "General")))], [videos]);

  function handleVideoTimeUpdate(videoId: number, event: React.SyntheticEvent<HTMLVideoElement>) {
    if (!sessionUser) return;
    const element = event.currentTarget;
    const current = Math.floor(element.currentTime);
    const previous = watchMarkers.current[videoId];
    if (previous === undefined) {
      watchMarkers.current[videoId] = current;
      return;
    }
    const delta = current - previous;
    if (delta >= 5 && delta <= 30) {
      watchMarkers.current[videoId] = current;
      recordWatch.mutate({ videoId, seconds: delta, position: current, duration: Number.isFinite(element.duration) ? Math.round(element.duration) : null });
    } else if (delta < 0 || delta > 30) {
      watchMarkers.current[videoId] = current;
    }
  }

  async function handleFiles(files: FileList | File[]) {
    const file = Array.from(files).find((candidate) => candidate.type.startsWith("video/"));
    if (!file) {
      setUpload({ fileName: "No video selected", previewUrl: "", percent: 0, status: "error", message: "শুধু ভিডিও ফাইল নির্বাচন করুন।" });
      return;
    }
    retryFileRef.current = file;
    if (file.size > MAX_VIDEO_BYTES) {
      setUpload({ fileName: file.name, previewUrl: "", percent: 0, status: "error", message: "ভিডিওর সর্বোচ্চ আকার 50 MB।" });
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    setUpload({ fileName: file.name, previewUrl, percent: 0, status: "uploading" });
    try {
      const presigned = await createUpload.mutateAsync({ fileName: file.name, mimeType: file.type, sizeBytes: file.size });
      const stored = await uploadWithProgress(file, presigned.uploadUrl, (percent) => setUpload((current) => current ? { ...current, percent } : current));
      const durationSeconds = await readDuration(file);
      await completeUpload.mutateAsync({
        storageKey: stored.key,
        fileName: file.name,
        mimeType: file.type,
        sizeBytes: file.size,
        durationSeconds,
        qualityVariants: stored.qualityVariants,
        category: uploadCategory,
        tags: uploadTags,
      });
      setUpload({ fileName: file.name, previewUrl, percent: 100, status: "success", message: "ভিডিও জমা হয়েছে। Admin Confirm করলে homepage-এ দেখা যাবে।" });
      await refetch();
    } catch (error) {
      setUpload((current) => current ? { ...current, status: "error", message: error instanceof Error ? error.message : "আপলোড সম্পন্ন হয়নি। আবার চেষ্টা করুন।" } : current);
    }
  }

  function handleDrop(event: React.DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setIsDragging(false);
    void handleFiles(event.dataTransfer.files);
  }

  return (
    <div className="vault-shell min-h-screen">
      <header className="site-header">
        <div className="brand-lockup" aria-label="xvidos home">
          <div className="brand-mark"><span>x</span><i /></div>
          <div>
            <div className="brand-name">xvidos</div>
            <div className="brand-kicker">OPEN VIDEO VAULT <span>// 01</span></div>
          </div>
        </div>
        <div className="header-actions"><button type="button" className="theme-toggle" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}>{theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}{theme === "dark" ? "LIGHT" : "DARK"}</button>{sessionUser && <button type="button" className="profile-toggle notification-center-button" onClick={() => setNotificationCenterOpen(!notificationCenterOpen)} aria-label="Open notification center"><Bell size={15} />{(notificationHistory.data?.filter((item) => !item.readAt).length ?? 0) > 0 && <span className="notification-count-badge">{notificationHistory.data?.filter((item) => !item.readAt).length}</span>}</button>}<button type="button" className="profile-toggle" onClick={() => sessionUser ? setWalletCenterOpen(!walletCenterOpen) : startLogin("/")} aria-label="Open wallet center"><UserRound size={16} /></button>{installPrompt && <button type="button" className="install-app" onClick={async () => { await installPrompt.prompt(); const choice = await installPrompt.userChoice; if (choice.outcome === "accepted") toast.success("xvidos app install হয়েছে।"); setInstallPrompt(null); }}>INSTALL APP</button>}<Link href="/admin" className="admin-link">ADMIN</Link>{sessionUser ? <><span className="account-chip" title={sessionUser.email ?? sessionUser.openId}>{sessionUser.name || sessionUser.email || "GMAIL ACCOUNT"}</span><button className="auth-action" onClick={() => logout.mutate()} disabled={logout.isPending}>LOG OUT</button></> : <button className="auth-action login-action" onClick={() => startLogin("/")}>SIGN IN WITH GMAIL</button>}<div className="header-signal"><span className="live-dot" /> {sessionUser ? "GMAIL CONNECTED" : "PUBLIC VAULT"} · NO ALTERATIONS</div></div>
      <div className="mobile-notification-control"><button type="button" className="notification-toggle" onClick={async () => { if (!("Notification" in window)) return toast.error("এই browser phone notification support করে না।"); if (phoneAlertsEnabled) { const subscription = await navigator.serviceWorker?.ready.then((registration) => registration.pushManager.getSubscription()).catch(() => null); if (subscription?.endpoint) await unsubscribePush.mutateAsync({ endpoint: subscription.endpoint }); await subscription?.unsubscribe().catch(() => undefined); setPhoneAlertsEnabled(false); try { localStorage.setItem("xvidos-phone-alerts", "off"); } catch {} toast("Phone alerts OFF করা হয়েছে।"); return; } const permission = window.Notification.permission === "granted" ? "granted" : await window.Notification.requestPermission(); setNotificationPermission(permission); if (permission === "granted") { setPhoneAlertsEnabled(true); try { localStorage.setItem("xvidos-phone-alerts", "on"); } catch {} toast.success("Broadcast phone notification চালু হয়েছে।"); } }} aria-label="Toggle phone notifications"><Bell size={15} />{phoneAlertsEnabled ? "PHONE ALERTS ON" : "PHONE ALERTS OFF"}</button></div>
      </header>
      {walletCenterOpen && sessionUser && <aside className="wallet-center" aria-label="Wallet Center"><div className="wallet-center-head"><div><span className="section-code">USER / WALLET CENTER</span><h2>আপনার হিসাব</h2></div><button type="button" className="wallet-center-close" onClick={() => setWalletCenterOpen(false)} aria-label="Close wallet center"><X size={17} /></button></div><div className="wallet-summary-grid"><div><span>MAIN BALANCE</span><strong>{formatBdt(sessionUser.points)}</strong></div><div><span>TODAY EARNED</span><strong>{formatBdt(walletCenter.data?.dailyEarningPoints ?? 0)}</strong></div><div><span>MIN WITHDRAW</span><strong>{formatBdt(walletCenter.data?.minimumWithdrawPoints ?? 10000)}</strong></div></div><div className="wallet-center-section"><div className="section-code">TRANSACTION HISTORY / STATUS</div>{walletCenter.isLoading && <p className="wallet-center-muted">History loading...</p>}{!walletCenter.isLoading && walletCenter.data?.transactions.length === 0 && <p className="wallet-center-muted">কোনো wallet transaction নেই।</p>}{walletCenter.data?.transactions.map((transaction) => <article className="wallet-history-row" key={transaction.id}><div><strong>{transaction.type === "withdraw" ? "Withdraw" : "Recharge"} · {formatBdt(transaction.amountPoints)}</strong><span>{transaction.phoneNumber} · {transaction.method || transaction.operator || "—"}</span></div><span className={`request-status status-${transaction.status}`}>{transaction.status}</span><small>{transaction.adminNote || "Admin review pending"}</small></article>)}</div><div className="wallet-center-section"><div className="section-code">PREMIUM MEMBERSHIP / AD-FREE</div><div className="membership-grid">{monetizationCatalog.data?.map((plan) => <article className="membership-card" key={plan.id}><strong>{plan.name}</strong><span>{plan.description}</span><b>৳{(plan.pricePoints / 100).toFixed(2)} / {plan.durationDays} days</b><button type="button" disabled={!sessionUser || requestMembership.isPending} onClick={() => sessionUser ? requestMembership.mutate({ planId: plan.id }) : startLogin("/")}>{sessionUser ? "Request approval" : "Sign in to join"}</button></article>)}</div>{monetizationMe.data?.subscription && <p className="wallet-center-muted">Current membership: {monetizationMe.data.subscription.plan?.name || "Premium"}</p>}<div className="creator-earnings-line">Creator earnings: ৳{((monetizationMe.data?.earnings || []).reduce((sum, entry) => sum + entry.amountPoints, 0) / 100).toFixed(2)}</div></div><div className="wallet-center-section"><div className="section-code">BALANCE CHANGE AUDIT</div>{walletCenter.data?.auditLogs.slice(0, 8).map((entry) => <article className="audit-row" key={entry.id}><span>{entry.kind.replaceAll("_", " ")}</span><strong className={entry.deltaPoints >= 0 ? "audit-plus" : "audit-minus"}>{entry.deltaPoints >= 0 ? "+" : ""}{entry.deltaPoints} pts</strong></article>)}</div></aside>}

      {notificationCenterOpen && sessionUser && <aside className="notification-center-panel" aria-label="Notification center"><div className="wallet-center-head"><div><span className="section-code">NOTIFICATION CENTER</span><h2>Alerts</h2></div><span className={`notification-unread-count ${(notificationHistory.data?.filter((item) => !item.readAt).length ?? 0) > 0 ? "has-unread" : ""}`}>{notificationHistory.data?.filter((item) => !item.readAt).length ? `নতুন ${notificationHistory.data.filter((item) => !item.readAt).length}টি notification এসেছে` : "সব notification দেখা হয়েছে"}</span></div><div className="notification-category-tabs">{(["all", "broadcast", "new_video", "wallet", "security"] as const).map((category) => <button type="button" key={category} className={notificationCategory === category ? "is-active" : ""} onClick={() => setNotificationCategory(category)}>{category === "all" ? "All" : category.replace("_", " ")}</button>)}</div><div className="notification-list">{notificationHistory.data?.map((item) => <button type="button" className={`notification-history-item ${item.readAt ? "is-read" : "is-unread"}`} key={item.id} onClick={() => !item.readAt && markNotificationRead.mutate({ id: item.id })}><strong>{item.title}</strong><span>{item.message}</span><small>{item.category} · {new Date(item.createdAt).toLocaleString("bn-BD")}</small></button>)}</div><div className="notification-preferences"><span className="section-code">CATEGORY CONTROL</span>{(["broadcast", "newVideo", "wallet", "security"] as const).map((key) => <label key={key}><input type="checkbox" checked={Boolean(notificationPreferences.data?.[key])} onChange={(event) => { const current = notificationPreferences.data; if (!current) return; setNotificationPreferences.mutate({ broadcast: Boolean(current.broadcast), newVideo: Boolean(current.newVideo), wallet: Boolean(current.wallet), security: Boolean(current.security), [key]: event.target.checked }); }} /> {key === "newVideo" ? "New video" : key[0].toUpperCase() + key.slice(1)}</label>)}</div></aside>}
      <main className="vault-main">
        {rewardSettings.data?.captchaRewardVisible !== 0 && <section className="captcha-strip">
          <div><span className="section-code">00 / DAILY CAPTCHA REWARD</span><h2>Verify & earn points</h2><p>প্রতি সঠিক Captcha-তে {formatBdt(rewardSettings.data?.captchaRewardPoints ?? 10)}। প্রতিদিন সর্বোচ্চ {rewardSettings.data?.captchaDailyLimit ?? 20}টি claim; ভুল code-এ কোনো টাকা যোগ হবে না।</p></div>
          <div className="wallet-actions"><div className="main-balance"><span>MAIN BALANCE</span><strong>{formatBdt(sessionUser?.points ?? 0)}</strong><small>{sessionUser?.points ?? 0} points</small></div><Button variant="outline" onClick={() => setWalletPanel(walletPanel === "withdraw" ? null : "withdraw")}>Withdraw</Button><Button variant="outline" onClick={() => setWalletPanel(walletPanel === "recharge" ? null : "recharge")}>Recharge</Button></div>
          <div className="captcha-action"><strong className="captcha-visual" aria-label={`Captcha: ${captcha.data?.question ?? "C A P T C H A"}`} draggable="false" onCopy={(event) => event.preventDefault()} onCut={(event) => event.preventDefault()} onContextMenu={(event) => event.preventDefault()}>{(captcha.data?.question ?? "C A P T C H A").split(" ").map((character, index) => <i key={`${character}-${index}`} style={{ ["--captcha-index" as string]: index }}>{character}</i>)}</strong><input aria-label="Captcha answer" inputMode="text" maxLength={6} value={captchaAnswer} onChange={(event) => setCaptchaAnswer(event.target.value.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 6))} placeholder="6 chars" /><Button disabled={!captcha.data || verifyCaptcha.isPending || captchaAnswer.length !== 6} onClick={() => { if (!sessionUser) { sessionStorage.setItem("xvidos-pending-captcha", JSON.stringify({ token: captcha.data!.token, answer: captchaAnswer })); setCaptchaMessage("Gmail login-এর পর এই Captcha নিজে থেকেই submit হবে..."); startLogin("/"); return; } verifyCaptcha.mutate({ token: captcha.data!.token, answer: captchaAnswer }); }}>{sessionUser ? "Submit +10" : "Sign in & submit"}</Button><button type="button" className="captcha-audio" disabled={!captcha.data || typeof window === "undefined" || !("speechSynthesis" in window)} onClick={() => { const code = (captcha.data?.question ?? "").split(" ").join(", "); window.speechSynthesis.cancel(); const speech = new SpeechSynthesisUtterance(code); speech.lang = "en-US"; speech.rate = 0.72; window.speechSynthesis.speak(speech); }} aria-label="Listen to Captcha"><Volume2 size={14} /> Listen</button><button type="button" className="captcha-refresh" disabled={captcha.isFetching || verifyCaptcha.isPending} onClick={() => { setCaptchaAnswer(""); setCaptchaMessage(null); void captcha.refetch(); }} aria-label="Generate a new Captcha">↻ New Captcha</button></div>
          {captchaMessage && <span className="captcha-message">{captchaMessage}</span>}
          {walletPanel && <div className="wallet-panel"><strong>{walletPanel === "withdraw" ? "Withdraw (BDT)" : "Mobile recharge (BDT, max ৳50)"}</strong>{walletPanel === "withdraw" ? <><input value={walletAmount} onChange={(event) => setWalletAmount(event.target.value.replace(/[^\d.]/g, ""))} placeholder="Amount in BDT" inputMode="decimal" /><select value={walletMethod} onChange={(event) => setWalletMethod(event.target.value)}><option value="" disabled>Choose method</option><option>bKash</option><option>Nagad</option><option>Bank</option></select><input value={walletPhone} onChange={(event) => setWalletPhone(event.target.value.replace(/\D/g, "").slice(0, 11))} placeholder="01XXXXXXXXX" inputMode="tel" /><Button disabled={createWalletRequest.isPending} onClick={() => { if (!sessionUser) return startLogin("/"); createWalletRequest.mutate({ type: "withdraw", amountPoints: Math.round(Number(walletAmount) * POINTS_PER_BDT), phoneNumber: walletPhone, method: walletMethod as "bKash" | "Nagad" | "Bank" }); }}>Request withdraw</Button></> : <><select value={walletOperator} onChange={(event) => setWalletOperator(event.target.value)}><option value="" disabled>Choose operator</option><option>Robi</option><option>Airtel</option><option>Grameenphone</option></select><input value={walletPhone} onChange={(event) => setWalletPhone(event.target.value.replace(/\D/g, "").slice(0, 11))} placeholder="01XXXXXXXXX" inputMode="tel" /><input value={walletAmount} onChange={(event) => setWalletAmount(event.target.value.replace(/[^\d.]/g, ""))} placeholder="Amount in BDT (max 50)" inputMode="decimal" /><Button disabled={createWalletRequest.isPending} onClick={() => { if (!sessionUser) return startLogin("/"); createWalletRequest.mutate({ type: "recharge", amountPoints: Math.min(5000, Math.round(Number(walletAmount) * POINTS_PER_BDT)), phoneNumber: walletPhone, operator: walletOperator as "Robi" | "Airtel" | "Grameenphone" }); }}>Request recharge</Button></>}</div>}
        </section>}
        <section className="intro-row">
          <div>
            <p className="eyebrow"><Sparkles size={14} /> YOUR MEDIA, UNTOUCHED</p>
            <h1>আপনার ভিডিও।<br /><em>যেভাবে আছে।</em></h1>
          </div>
          <div className="vault-stat"><span className="stat-label">ARCHIVE INDEX</span><strong>{String(videos.length).padStart(2, "0")}</strong><span className="stat-foot">ORIGINAL FILES</span></div>
        </section>

        <section className="workspace-grid">
          <section className="gallery-field">
            <div className="gallery-toolbar">
              <div><div className="section-code">02 / VIDEO GALLERY</div><h2>আপনার archive</h2></div>
              <div className="gallery-controls"><label className="search-box"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="নাম, tag বা category খুঁজুন..." aria-label="Search videos" /></label><select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} aria-label="Filter category">{categories.map((category) => <option key={category} value={category}>{category === "all" ? "সব category" : category}</option>)}</select><select value={sortMode} onChange={(event) => setSortMode(event.target.value as typeof sortMode)} aria-label="Sort videos"><option value="newest">Featured / Newest</option><option value="oldest">Oldest</option><option value="most-watched">Most watched</option><option value="recently-watched">Recently watched</option></select></div>
            </div>

            {isLoading && <div className="state-card"><Loader2 className="spin" size={22} /><p>archive index পড়া হচ্ছে...</p></div>}
            {isError && <div className="state-card state-error"><AlertCircle size={22} /><p>ভিডিও index পাওয়া যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।</p></div>}
            {!isLoading && !isError && filteredVideos.length === 0 && (
              <div className="empty-state"><div className="empty-symbol"><Clapperboard size={30} /></div><div><span className="section-code">ARCHIVE EMPTY</span><h3>{search ? "কোনো matching file নেই" : "প্রথম ভিডিওটি যোগ করুন"}</h3><p>{search ? "অন্য কোনো নাম দিয়ে খুঁজে দেখুন।" : "বাম পাশের upload rail থেকে আপনার প্রথম original video যোগ করুন।"}</p></div>{search ? <Button variant="outline" onClick={() => setSearch("")}>সব দেখুন</Button> : null}</div>
            )}
            {!isLoading && !isError && filteredVideos.length > 0 && (
              <div className="video-grid">
                {filteredVideos.map((video) => (
                  <article className="raw-video-item" id={`video-${video.id}`} key={video.id}>
                    {(() => { const variants = parseQualityVariants(video.qualityVariants); const selected = selectedQuality[video.id] ?? "auto"; const selectedVariant = variants.find((variant) => variant.label === selected); const source = selectedVariant?.url ?? video.storageUrl; const locked = !video.storageUrl; const isFallback = selected !== "auto" && !selectedVariant; const downloadName = `${video.title}-${selected === "auto" || isFallback ? "original" : selected}.mp4`; const resumePosition = collections.data?.recent.find((entry) => entry.videoId === video.id)?.lastPositionSeconds ?? 0; const liked = collections.data?.likedIds.includes(video.id); const favorited = collections.data?.favoriteIds.includes(video.id); return <>{locked ? <div className="premium-locked-player"><div className="premium-lock-icon">◆</div><strong>PREMIUM VIDEO</strong><span>Active subscription ছাড়া এই ভিডিও দেখা যাবে না।</span><button type="button" onClick={() => sessionUser ? setWalletCenterOpen(true) : startLogin("/")}>{sessionUser ? "VIEW MEMBERSHIP PLANS" : "SIGN IN TO SUBSCRIBE"}</button></div> : <video key={`${video.id}-${source}`} className="raw-video" src={source} controls playsInline preload="metadata" crossOrigin="anonymous" onPlay={() => { if (!viewedVideos.current.has(video.id)) { viewedVideos.current.add(video.id); recordView.mutate({ videoId: video.id }); } }} onLoadedMetadata={(event) => { if (resumePosition > 5 && event.currentTarget.currentTime === 0) event.currentTarget.currentTime = resumePosition; }} onTimeUpdate={(event) => handleVideoTimeUpdate(video.id, event)} />}<div className="quality-tools"><label className="quality-selector"><span>QUALITY / DOWNLOAD</span><select value={selected} onChange={(event) => { const next = event.target.value; setSelectedQuality((current) => ({ ...current, [video.id]: next })); if (next !== "auto" && !variants.some((variant) => variant.label === next)) toast.info(`${next} source এখনও তৈরি হয়নি। এই পুরোনো video-র জন্য Original চালানো হচ্ছে।`); }}><option value="auto">Original / Auto</option>{QUALITY_LEVELS.map((label) => <option key={label} value={label}>{label}{variants.some((variant) => variant.label === label) ? " · ready" : " · unavailable"}</option>)}</select></label><a className="quality-download" href={source} download={downloadName}>DOWNLOAD {selected === "auto" || isFallback ? "ORIGINAL" : selected}</a></div><div className="video-actions"><button type="button" className={liked ? "is-active" : ""} onClick={() => sessionUser ? likeVideo.mutate({ videoId: video.id }) : startLogin("/")}><Heart size={14} /> {video.likeCount ?? 0}</button><button type="button" className={favorited ? "is-active" : ""} onClick={() => sessionUser ? favoriteVideo.mutate({ videoId: video.id }) : startLogin("/")}><Star size={14} /> Save</button><button type="button" onClick={() => { const reason = window.prompt("কেন report করছেন?"); if (reason?.trim()) reportVideo.mutate({ videoId: video.id, reason: reason.trim() }); }}>Report</button></div></> })()}
                    <div className="card-body"><div className="card-index">{String(video.id).padStart(2, "0")} <span>·</span> {video.featured ? "FEATURED" : "ORIGINAL"}</div><h3 title={video.title}>{video.title}</h3><div className="card-details"><span>{video.category || "General"}</span><span>{video.tags || "no tags"}</span><span>{video.viewCount ?? 0} views</span><span>{formatDate(video.createdAt)}</span></div>{(() => { const related = (videos as VideoRecord[]).filter((candidate) => candidate.id !== video.id && candidate.category === video.category).slice(0, 2); return related.length ? <div className="related-videos"><small>RELATED</small>{related.map((candidate) => <button type="button" key={candidate.id} onClick={() => document.getElementById(`video-${candidate.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" })}>{candidate.title}</button>)}</div> : null; })()}</div>
                  </article>
                ))}
              </div>
            )}
          </section>
        </section>
      </main>

      <footer className="site-footer"><span><HardDrive size={14} /> STORAGE / READY</span><span>NO FILTERS · NO FRAMES · JUST VIDEO</span><span>XV / 2026</span></footer>
    </div>
  );
}
