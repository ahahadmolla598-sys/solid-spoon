# xvidos কাজের তালিকা

## 1. লগইনবিহীন ভিডিও ও গ্যালারি অভিজ্ঞতা — সম্পন্ন
- কোনো ধরনের লগইন পেজ, সাইন-আপ বা অ্যাকাউন্ট বাধ্যতামূলকতা ছাড়া ওয়েবসাইট সরাসরি ব্যবহার করা যাবে। `App.tsx`-এ শুধু public home route আছে; ভিডিও procedures public এবং কোনো login gate নেই।
- মোবাইল ও ডেস্কটপে ব্যবহারযোগ্য রেসপনসিভ ইন্টারফেস থাকবে। `index.css`-এর mobile breakpoint-এ upload rail ও gallery এক কলামে stack হয়; desktop screenshot এবং mobile screenshot-এ layout যাচাই করা হয়েছে।
- আপলোড করা ভিডিওগুলোর ব্রাউজযোগ্য ভিডিও গ্যালারি থাকবে। `videos.list` এবং responsive video-card gallery implement করা হয়েছে।
- গ্যালারি থেকেই ভিডিও প্লে, পজ, সিক ও ভলিউম নিয়ন্ত্রণ করা যাবে। নির্বাচিত card-এর stable storage URL native HTML5 `<video controls>` player-এ খোলে।

## 2. গ্যালারি থেকে ভিডিও আপলোড — সম্পন্ন
- ব্যবহারকারী নিজের ডিভাইসের গ্যালারি বা file picker থেকে ভিডিও ফাইল নির্বাচন ও আপলোড করতে পারবে। `accept="video/*"` file picker এবং drag-and-drop দুটোই আছে।
- আপলোডের অগ্রগতি এবং সফলতা/ব্যর্থতার স্পষ্ট স্ট্যাটাস প্রদর্শন হবে। Presigned PUT upload-এর XHR progress, percent, success message ও error message আছে।
- আপলোড সফল হলে ভিডিওটি গ্যালারিতে যুক্ত হবে এবং failure হলে retry/আবার চেষ্টা করার সুযোগ থাকবে। Complete mutation-এর পর list refetch হয়; failure card-এ আবার চেষ্টা button আছে।

## 3. মূল ভিডিও অক্ষত রাখা — সম্পন্ন
- যে ভিডিও অ্যাড করা হবে সেটি আসল ভিডিও হিসেবেই থাকবে। Browser file bytes সরাসরি presigned object-storage PUT-এ যায়; server কোনো transcoding করে না।
- কোনো ফিল্টার, ফিল্ম, ফ্রেম, ক্রপ, রূপান্তর বা দৃশ্যগত পরিবর্তন যোগ করা যাবে না। Gallery-তে thumbnail, play badge বা overlay নেই; প্রতিটি item সরাসরি native `<video controls>` player এবং নিজের aspect ratio-তে দেখানো হয়।

## 4. Durable video infrastructure — সম্পন্ন
- ভিডিও bytes managed object storage-এ streaming server upload-এর মাধ্যমে সংরক্ষিত হবে এবং ভিডিও metadata database-এ থাকবে। `storagePutStream`, same-origin `/api/videos/upload`, stable `/manus-storage/...` URL, `videos` schema ও migration যুক্ত হয়েছে।
- গ্যালারি stable storage address থেকে মূল ভিডিও পুনরুদ্ধার করবে। `videos.list` database rows থেকে stable storage URL ফেরত দেয়।

## 5. অনুমোদিত admin panel — সম্পন্ন
- `/admin` route থাকবে এবং homepage visitor login ছাড়াই ব্যবহার করতে পারবে।
- শুধু `afsiarmd@gmail.com` email submit করলে OAuth verification শুরু হবে; server-side session email যাচাই ছাড়া admin panel বা admin upload endpoint খুলবে না।
- Admin panel থেকে যোগ করা প্রতিটি ভিডিও homepage gallery-তে database index এবং managed storage URL-এর মাধ্যমে দেখা যাবে।
- Admin upload-ও original video bytes streaming path ব্যবহার করবে; কোনো filter, frame, crop বা conversion হবে না।
- সাধারণ user upload প্রথমে `pending` status-এ moderation queue-তে থাকবে; Admin Confirm করলে `approved` হয়ে homepage-এ দেখাবে, Reject করলে `rejected` হয়ে homepage-এ দেখাবে না।

## 6. Captcha points ও live management — সম্পন্ন
- Homepage-এর উপরে functional arithmetic Captcha থাকবে; signed-in user সঠিকভাবে submit করলে database balance-এ ১০ points instant যোগ হবে।
- Admin panel-এ registered users-এর online/offline presence, points Add/Deduct, Ban/Unban এবং all-video visible/hidden switch থাকবে।
- Banned user-এর authenticated API access block হবে; homepage শুধু `approved` এবং `visible` ভিডিও দেখাবে।
- User এবং video management যথাক্রমে ৮ সেকেন্ড ও ৫ সেকেন্ড polling-এ দ্রুত sync হবে; video player-এ `preload="metadata"`, `crossorigin="anonymous"`, `playsinline` থাকবে।

## 7. Main balance ও wallet actions — সম্পন্ন
- `00 / DAILY CAPTCHA REWARD` strip-এর উপরে main points balance স্পষ্টভাবে দেখাবে এবং পাশে Withdraw ও Recharge button থাকবে।
- Captcha এখন ৬-character English alphanumeric code (যেমন `ha9rje`), প্রতিটি character আলাদা spacing-এ দেখাবে; সঠিক হলে ১০ points যোগ হবে।
- Currency mapping: ১০ points = ৳০.১০; অর্থাৎ ১০০ BDT recharge = ১০,০০০ points। Main balance BDT ও points দুটোতেই দেখাবে। Recharge form-এ Robi, Airtel ও Grameenphone operator এবং mobile number field থাকবে; Withdraw form-এ BDT amount ও method থাকবে।
- Correct Captcha submit server-side account balance-এ automatically ১০ points/৳০.১০ যোগ করবে; wrong code-এ কোনো points যোগ হবে না। প্রতি Bangladesh date-এ account-পিছু সর্বোচ্চ ৩০টি claim enforce হবে।
- Recharge request-এর server-side maximum ৳৫০ (৫,০০০ points) enforce হবে; UI limit bypass করলেও API request reject হবে।

## 8. Real wallet request database ও admin approval — সম্পন্ন
- Signed-in user-এর Withdraw/Recharge form request database-এ `pending` status-এ সংরক্ষণ করবে; name, email, amount points, phone number, operator/method এবং created time রাখা হবে।
- Admin panel-এর Wallet Requests queue-তে Recharge ও Withdraw আলাদা type হিসেবে দেখা যাবে এবং Admin Approve/Reject করতে পারবে।
- Provider/API credentials না দেওয়া পর্যন্ত কোনো automatic টাকা পাঠানো বা mobile recharge হবে না; approved status কেবল manual processing-ready approval হিসেবে থাকবে।

## 9. দৃশ্যমান Gmail login system — সম্পন্ন
- Homepage header-এ `SIGN IN WITH GMAIL` button থাকবে; Gmail OAuth সম্পন্ন হলে account name/email, `GMAIL CONNECTED` state এবং `LOG OUT` button দেখা যাবে।
- Captcha reward ও wallet request signed-in account-এর balance-এ যুক্ত হবে; logout করলে session-based balance actions বন্ধ থাকবে।
- User code লিখে `Sign in & submit` চাপলে code/token session storage-এ নিরাপদে ধরে রাখা হবে; Gmail login শেষ হলে একই সঠিক Captcha স্বয়ংক্রিয়ভাবে verify হবে, তাই login-এর পরে আবার code লিখতে হবে না।

## 10. Realtime presence, reward visibility ও admin balance controls — সম্পন্ন
- Signed-in user প্রতি ১৫ সেকেন্ডে heartbeat পাঠাবে; Admin User Section সর্বোচ্চ ৪৫ সেকেন্ড পুরনো heartbeat-কে সবুজ `ONLINE NOW`, নতুবা লাল `OFFLINE` দেখাবে এবং ৫ সেকেন্ডে refresh হবে।
- Admin `DAILY CAPTCHA REWARD` section Visible/Hidden করলে homepage-এ reward block অদৃশ্য/পুনরায় দৃশ্যমান হবে এবং setting database-এ থাকবে।
- Admin user row-তে BDT amount লিখে Add বা Deduct করলে server-side points balance-এ amount × ১০০ প্রয়োগ হবে; current BDT ও points দুটোই দেখা যাবে।

## 11. Large video upload 413 fix — সম্পন্ন
- Browser upload এখন trusted same-origin streaming server route ব্যবহার করে; cross-origin presigned PUT-এর CORS/network interruption আর হবে না।
- User ও Admin UI এবং server route সর্বোচ্চ ৫০ MB enforce করে; বেশি হলে upload শুরুর আগেই পরিষ্কার `ভিডিওর সর্বোচ্চ আকার 50 MB` message দেখা যাবে, 413 HTML নয়।

## 12. Realtime online presence ও video watch time — সম্পন্ন
- Gmail-এ signed-in Home user এবং Admin panel—দুই জায়গা থেকেই প্রতি ১৫ সেকেন্ডে heartbeat পাঠাবে; Admin user list ৫ সেকেন্ডে refresh করবে, ৪৫ সেকেন্ড heartbeat না এলে offline দেখাবে।
- Signed-in user video player-এ অন্তত ৫ সেকেন্ড watch progress হলে user Gmail/name, video title/file, accumulated seconds এবং stable `UNIT XV-000001` code সহ `VIDEO WATCH TIME` admin queue-তে জমা হবে।
- Watch data database-এ user+video অনুযায়ী aggregate হবে এবং Admin Panel realtime polling-এ নতুন activity দেখাবে।

## 13. Wallet request balance reservation — সম্পন্ন
- Withdraw বা Recharge request submit করার সময় requested points user-এর balance থেকে atomic ভাবে কেটে pending request-এ reserve হবে; balance যথেষ্ট না হলে request তৈরি হবে না।
- Admin request reject করলে reserved points একবারই user balance-এ ফেরত যাবে; approve করলে আর কোনো দ্বিতীয় debit হবে না।

## 14. Configurable daily Captcha limit — সম্পন্ন
- Default daily Captcha limit ২০টি থাকবে এবং server-side claim enforcement একই configured limit ব্যবহার করবে।
- Admin Panel থেকে limit ১–১০০০-এর মধ্যে বাড়ানো, কমানো বা নতুন limit দিয়ে replace করা যাবে; Homepage-এ বর্তমান limit প্রদর্শিত হবে।

## 15. Configurable per-Captcha reward — সম্পন্ন
- Default প্রতি সঠিক Captcha reward ১০ পয়সা/১০ points থাকবে; Admin Panel থেকে ১–১০,০০০ পয়সার মধ্যে নতুন reward replace করা যাবে।
- Server points update, Home reward copy এবং successful claim message একই Admin-configured per-Captcha reward ব্যবহার করবে।

## 16. User experience notifications ও PWA — সম্পন্ন
- Existing Sonner toast system Home-এর Captcha/wallet feedback এবং Admin-এর balance/settings feedback-এ ব্যবহার হবে।
- xvidos-এর application-owned manifest, icon ও service worker থাকবে; supported mobile browser-এ `INSTALL APP` prompt button দেখা যাবে এবং standalone app হিসেবে install করা যাবে।

## 17. Admin broadcast notifications — সম্পন্ন
- Admin Panel থেকে title ও message লিখে একটি notification সকল Homepage visitor/user-এর কাছে পাঠানো যাবে।
- Notification database-এ সংরক্ষিত হবে; Homepage public polling-এর মাধ্যমে সর্বোচ্চ ৫ সেকেন্ডে নতুন broadcast toast দেখাবে।

## 18. User Wallet Center ও balance audit — সম্পন্ন
- Dark/Light toggle-এর পাশে human icon থাকবে; signed-in user সেটিতে click করলে realtime Wallet Center খুলবে।
- Wallet Center-এ Wallet Transaction History, Withdraw/Recharge status, Admin approval note, ৳100 minimum withdraw rule, আজকের Captcha earning summary এবং Balance Change Audit Trail দেখা যাবে।
- Wallet request reserve/refund, Captcha reward ও Admin Add/Deduct—সব balance change audit log-এ সংরক্ষিত হবে; Admin wallet review-তে note লেখা যাবে।

## 19. Multi-quality video playback — সম্পন্ন
- Original upload file unchanged থাকবে; upload processing-এ 144p, 240p, 360p, 480p, 720p এবং 1080p MP4 quality variants তৈরি ও storage-এ রাখা হবে।
- Homepage video player-এ available quality selector থাকবে; quality বদলালে selected source-এ playback চলবে। Source resolution-এর বেশি level upscale হতে পারে, কিন্তু নতুন detail তৈরি হবে না।
- একই selector থেকে selected quality দেখা যাবে এবং `DOWNLOAD ORIGINAL` বা selected `DOWNLOAD 144p/240p/...` button-এ সেই নির্দিষ্ট file download হবে।
- Selector সব 144p–1080p option দেখাবে; generated variant থাকলে `ready` source play/download হবে, পুরোনো record-এ unavailable status ও safe Original fallback দেখাবে।

## 20. Realtime wallet status refresh — সম্পন্ন
- Wallet Center প্রতি ২ সেকেন্ডে transaction status refresh করবে; approved status সবুজ badge/toast এবং rejected status লাল badge/toast হিসেবে দেখাবে।
- Status change হলে main balance ও Wallet Center summary fresh session data দিয়ে update হবে।

## 21. Enhanced quality upscale — সম্পন্ন
- Quality variants তৈরির সময় Lanczos scaling, unsharp sharpening, CRF 19, slow H.264 encode, AAC 160k এবং yuv420p ব্যবহার হবে, যাতে upscale output আগের মতো soft না থাকে।
- Original file অপরিবর্তিত থাকবে; low-resolution source-এ enhancement clarity/edge উন্নত করবে, কিন্তু source-এ না থাকা সত্যিকারের detail AI ছাড়া তৈরি করতে পারবে না।

## 22. Timeout-safe admin upload — সম্পন্ন
- Upload request শুধু original file save করে দ্রুত response দেবে; six quality variants background processing-এ তৈরি হবে, যাতে gateway `524` timeout হলেও Admin video complete হয়ে Homepage gallery-তে যোগ হয়।
- Background processing শেষ হলে `qualityVariants` database metadata update হবে এবং Homepage polling-এর মাধ্যমে selector-এ `ready` options দেখা যাবে।

## 23. Compact watch time ও broadcast phone alerts — সম্পন্ন
- Admin VIDEO WATCH TIME প্রতিটি activity পাঁচটি compact line-এ দেখাবে: USER, GMAIL, VIDEO, UNIT CODE/FILE এবং WATCHED।
- Homepage broadcast polling প্রতি ২ সেকেন্ডে নতুন message ধরবে; user `ENABLE PHONE ALERTS` চাপলে browser/PWA native phone notification-ও দেখাবে, পাশাপাশি in-page toast থাকবে।

## Validation evidence

`pnpm check`, `pnpm test` (2 files / 6 tests), `pnpm build`, `/api/health`, `/manus-routes.json` এবং `videos.list` endpoint সফলভাবে যাচাই করা হয়েছে।
