import { TRPCError } from "@trpc/server";
import { randomBytes } from "crypto";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { addAdminActivity, addPoints, adjustPoints, approveMembershipInvoice, claimCaptchaReward, createAppNotification, createBroadcastNotification, createInvoice, createVideoReport, createWalletRequest, deletePushSubscription, getLatestBroadcastNotification, getNotificationPreferences, getPushKeys, getSiteSettings, getUserByOpenId, getUserSubscription, getUserVideoCollections, insertVideo, listAdminActivityLogs, listAllVideos, listBalanceAuditLogs, listCreatorEarnings, listMonetizationPlans, listPendingInvoices, listPendingVideos, listUserNotifications, listUserWalletHistory, listUsers, listVideoWatchStats, listVideos, listWalletRequests, markNotificationRead, recordVideoView, recordVideoWatch, savePushSubscription, setCaptchaDailyLimit, setCaptchaRewardPoints, setCaptchaRewardVisible, setNotificationPreferences, setPremiumOnly, setUserBanned, setVideoAccess, setVideoDeleted, setVideoFeatured, setVideoStatus, setVideoVisibility, setWalletRequestStatus, toggleVideoFavorite, toggleVideoLike, touchUser } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { sendBroadcastPush, sendUserPush } from "./push";

const MAX_VIDEO_BYTES = 50 * 1024 * 1024;
const safeFileName = (name: string) => name.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 180) || "video.mp4";
const captchaChallenges = new Map<string, { answer: string; expiresAt: number }>();
const captchaFailures = new Map<string, { count: number; windowStartedAt: number; lockedUntil?: number }>();
const CAPTCHA_FAILURE_LIMIT = 5;
const CAPTCHA_FAILURE_WINDOW_MS = 10 * 60 * 1000;
const CAPTCHA_LOCK_MS = 5 * 60 * 1000;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => ctx.user ? (await getUserByOpenId(ctx.user.openId)) ?? ctx.user : null),
    heartbeat: protectedProcedure.mutation(async ({ ctx }) => ({ ok: true, lastSeenAt: await touchUser(ctx.user.openId) })),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      return { success: true };
    }),
  }),
  captcha: router({
    challenge: publicProcedure.query(() => {
      const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
      const code = Array.from({ length: 6 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
      const token = randomBytes(18).toString("hex");
      captchaChallenges.set(token, { answer: code, expiresAt: Date.now() + 5 * 60 * 1000 });
      return { token, question: code.split("").join(" ") };
    }),
    verify: publicProcedure.input(z.object({ token: z.string().min(20), answer: z.string().regex(/^[a-z0-9]{6}$/i) })).mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in to claim points" });
      const now = Date.now();
      const failureState = captchaFailures.get(ctx.user.openId);
      if (failureState?.lockedUntil && failureState.lockedUntil > now) {
        const waitMinutes = Math.max(1, Math.ceil((failureState.lockedUntil - now) / 60000));
        throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: `অনেকবার ভুল Captcha হয়েছে। ${waitMinutes} মিনিট পরে আবার চেষ্টা করুন।` });
      }
      if (failureState && now - failureState.windowStartedAt >= CAPTCHA_FAILURE_WINDOW_MS) captchaFailures.delete(ctx.user.openId);
      const challenge = captchaChallenges.get(input.token);
      captchaChallenges.delete(input.token);
      if (!challenge || challenge.expiresAt < now || String(challenge.answer) !== input.answer.toLowerCase()) {
        const current = captchaFailures.get(ctx.user.openId);
        const next = current && now - current.windowStartedAt < CAPTCHA_FAILURE_WINDOW_MS ? { ...current, count: current.count + 1 } : { count: 1, windowStartedAt: now };
        if (next.count >= CAPTCHA_FAILURE_LIMIT) next.lockedUntil = now + CAPTCHA_LOCK_MS;
        captchaFailures.set(ctx.user.openId, next);
        throw new TRPCError({ code: next.lockedUntil ? "TOO_MANY_REQUESTS" : "BAD_REQUEST", message: next.lockedUntil ? "৫ বার ভুল Captcha হয়েছে। ৫ মিনিটের জন্য সাময়িকভাবে বন্ধ করা হয়েছে।" : `Captcha answer incorrect. বাকি চেষ্টা: ${CAPTCHA_FAILURE_LIMIT - next.count}` });
      }
      captchaFailures.delete(ctx.user.openId);
      const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(new Date());
      const settings = await getSiteSettings();
      const dailyLimit = Math.max(1, settings.captchaDailyLimit || 20);
      const rewardPoints = Math.max(1, settings.captchaRewardPoints || 10);
      const reward = await claimCaptchaReward(ctx.user.openId, today, dailyLimit, rewardPoints);
      if (!reward) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: `আজকের ${dailyLimit}টি Captcha limit পূর্ণ হয়েছে` });
      return { pointsAwarded: rewardPoints, balance: reward.user.points, balanceBdt: (reward.user.points / 100).toFixed(2), claimsToday: reward.claimsToday, dailyLimit };
    }),
  }),
  settings: router({
    public: publicProcedure.query(() => getSiteSettings()),
  }),
  notifications: router({
    latest: publicProcedure.query(() => getLatestBroadcastNotification()),
    history: protectedProcedure.input(z.object({ category: z.enum(["all", "broadcast", "new_video", "wallet", "security", "system"]).default("all") })).query(({ ctx, input }) => listUserNotifications(ctx.user.openId, input.category === "all" ? undefined : input.category)),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => markNotificationRead(input.id, ctx.user.openId)),
    preferences: protectedProcedure.query(({ ctx }) => getNotificationPreferences(ctx.user.openId)),
    setPreferences: protectedProcedure.input(z.object({ broadcast: z.boolean(), newVideo: z.boolean(), wallet: z.boolean(), security: z.boolean() })).mutation(({ ctx, input }) => setNotificationPreferences(ctx.user.openId, input)),
    publicKey: publicProcedure.query(async () => (await getPushKeys()).publicKey),
    subscribe: publicProcedure.input(z.object({ endpoint: z.string().url().max(2048), keys: z.object({ p256dh: z.string().min(20).max(512), auth: z.string().min(10).max(512) }) })).mutation(({ ctx, input }) => savePushSubscription({ endpoint: input.endpoint, p256dh: input.keys.p256dh, auth: input.keys.auth, userOpenId: ctx.user?.openId ?? null })),
    unsubscribe: publicProcedure.input(z.object({ endpoint: z.string().url().max(2048) })).mutation(({ input }) => deletePushSubscription(input.endpoint)),
  }),
  walletCenter: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      const [transactions, auditLogs] = await Promise.all([listUserWalletHistory(ctx.user.openId), listBalanceAuditLogs(ctx.user.openId)]);
      const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(new Date());
      const dailyEarningPoints = auditLogs.filter((entry) => entry.kind === "captcha_reward" && new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(new Date(entry.createdAt)) === today).reduce((sum, entry) => sum + entry.deltaPoints, 0);
      return { transactions, auditLogs, dailyEarningPoints, minimumWithdrawPoints: 10000 };
    }),
  }),
  videos: router({
    list: publicProcedure.query(({ ctx }) => listVideos(ctx.user?.openId ?? null)),
    recordView: publicProcedure.input(z.object({ videoId: z.number().int().positive() })).mutation(({ input }) => recordVideoView(input.videoId)),
    recordWatch: protectedProcedure.input(z.object({ videoId: z.number().int().positive(), seconds: z.number().int().min(1).max(30), position: z.number().int().min(0), duration: z.number().int().positive().nullable() })).mutation(({ ctx, input }) => recordVideoWatch(ctx.user.openId, input.videoId, input.seconds, input.position, input.duration)),
    collections: protectedProcedure.query(({ ctx }) => getUserVideoCollections(ctx.user.openId)),
    like: protectedProcedure.input(z.object({ videoId: z.number().int().positive() })).mutation(({ ctx, input }) => toggleVideoLike(input.videoId, ctx.user.openId)),
    favorite: protectedProcedure.input(z.object({ videoId: z.number().int().positive() })).mutation(({ ctx, input }) => toggleVideoFavorite(input.videoId, ctx.user.openId)),
    report: publicProcedure.input(z.object({ videoId: z.number().int().positive(), reason: z.string().trim().min(3).max(255) })).mutation(({ ctx, input }) => createVideoReport({ ...input, userOpenId: ctx.user?.openId ?? null })),
    createUpload: publicProcedure
      .input(z.object({
        fileName: z.string().min(1).max(255),
        mimeType: z.string().regex(/^video\//, "Only video files are accepted"),
        sizeBytes: z.number().int().positive().max(MAX_VIDEO_BYTES),
      }))
      .mutation(async ({ input }) => {
        const fileName = safeFileName(input.fileName);
        return { uploadUrl: "/api/videos/upload", fileName, sizeBytes: input.sizeBytes, mimeType: input.mimeType };
      }),
    complete: publicProcedure
      .input(z.object({
        storageKey: z.string().regex(/^videos\/[a-zA-Z0-9._-]+$/),
        fileName: z.string().min(1).max(255),
        mimeType: z.string().regex(/^video\//),
        sizeBytes: z.number().int().positive().max(MAX_VIDEO_BYTES),
        durationSeconds: z.number().int().nonnegative().max(86400).nullable().optional(),
        qualityVariants: z.array(z.object({ label: z.string().regex(/^\d+p$/), url: z.string().min(1), height: z.number().int().positive() })).max(6).optional(),
        category: z.string().trim().min(1).max(80).optional(), tags: z.string().trim().max(500).optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          return await insertVideo({
            title: input.fileName.replace(/\.[^/.]+$/, ""),
            fileName: input.fileName,
            storageKey: input.storageKey,
            storageUrl: `/manus-storage/${input.storageKey}`,
            qualityVariants: input.qualityVariants ? JSON.stringify(input.qualityVariants) : null,
            mimeType: input.mimeType,
            sizeBytes: input.sizeBytes,
            durationSeconds: input.durationSeconds ?? null,
            status: "pending", category: input.category || "General", tags: input.tags || null,
          });
        } catch (error) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error instanceof Error ? error.message : "Could not save video" });
        }
      }),
  }),
  wallet: router({
    createRequest: publicProcedure.input(z.object({ type: z.enum(["withdraw", "recharge"]), amountPoints: z.number().int().positive().max(1000000), phoneNumber: z.string().regex(/^01[3-9]\d{8}$/, "Enter a valid Bangladesh mobile number"), operator: z.enum(["Robi", "Airtel", "Grameenphone"]).optional(), method: z.enum(["bKash", "Nagad", "Bank"]).optional() }).superRefine((value, ctx) => {
      if (value.type === "recharge" && !value.operator) ctx.addIssue({ code: "custom", path: ["operator"], message: "Choose a mobile operator" });
      if (value.type === "withdraw" && !value.method) ctx.addIssue({ code: "custom", path: ["method"], message: "Choose a withdrawal method" });
      if (value.type === "withdraw" && value.amountPoints < 10000) ctx.addIssue({ code: "custom", path: ["amountPoints"], message: "Minimum withdraw is ৳100" });
      if (value.type === "recharge" && value.amountPoints > 5000) ctx.addIssue({ code: "custom", path: ["amountPoints"], message: "Recharge limit is ৳50 per request" });
    })).mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in to submit a wallet request" });
      return createWalletRequest({ userOpenId: ctx.user.openId, type: input.type, amountPoints: input.amountPoints, phoneNumber: input.phoneNumber, operator: input.operator ?? null, method: input.method ?? null, status: "pending" });
    }),
  }),
  monetization: router({
    catalog: publicProcedure.query(() => listMonetizationPlans()),
    me: protectedProcedure.query(async ({ ctx }) => ({ subscription: await getUserSubscription(ctx.user.openId), earnings: await listCreatorEarnings(ctx.user.openId) })),
    requestMembership: protectedProcedure.input(z.object({ planId: z.number().int().positive(), promoCode: z.string().trim().max(40).optional() })).mutation(async ({ ctx, input }) => {
      const plans = await listMonetizationPlans();
      const plan = plans.find((entry) => entry.id === input.planId);
      if (!plan) throw new TRPCError({ code: "NOT_FOUND", message: "Membership plan পাওয়া যায়নি।" });
      const invoice = await createInvoice({ userOpenId: ctx.user.openId, itemType: "membership", itemId: plan.id, amountPoints: plan.pricePoints });
      return { status: "pending", invoiceNumber: invoice?.invoiceNumber, message: "Membership request admin approval-এর জন্য পাঠানো হয়েছে।" };
    }),
  }),
  admin: router({
    me: adminProcedure.query(({ ctx }) => ({ email: ctx.user.email, name: ctx.user.name })),
    users: adminProcedure.input(z.object({ search: z.string().trim().max(160).default("") })).query(({ input }) => listUsers(input.search)),
    activity: adminProcedure.query(() => listAdminActivityLogs()),
    watchStats: adminProcedure.query(() => listVideoWatchStats()),
    adjustPoints: adminProcedure.input(z.object({ openId: z.string().min(1), amount: z.number().int().min(-10000000).max(10000000) })).mutation(async ({ ctx, input }) => {
      if (input.openId === ctx.user.openId) throw new TRPCError({ code: "BAD_REQUEST", message: "Admin balance cannot be adjusted here" });
      const result = await adjustPoints(input.openId, input.amount, ctx.user.openId); await addAdminActivity({ actorOpenId: ctx.user.openId, actorEmail: ctx.user.email, action: input.amount >= 0 ? "balance_added" : "balance_deducted", targetOpenId: input.openId, details: `${Math.abs(input.amount)} points` }); return result;
    }),
    setBanned: adminProcedure.input(z.object({ openId: z.string().min(1), banned: z.boolean() })).mutation(async ({ ctx, input }) => {
      if (input.openId === ctx.user.openId) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot ban the active admin" });
      const result = await setUserBanned(input.openId, input.banned); await addAdminActivity({ actorOpenId: ctx.user.openId, actorEmail: ctx.user.email, action: input.banned ? "user_banned" : "user_unbanned", targetOpenId: input.openId }); return result;
    }),
    videos: adminProcedure.query(() => listAllVideos()),
    setVisibility: adminProcedure.input(z.object({ id: z.number().int().positive(), visibility: z.enum(["visible", "hidden"]) })).mutation(({ input }) => setVideoVisibility(input.id, input.visibility)),
    setFeatured: adminProcedure.input(z.object({ id: z.number().int().positive(), featured: z.boolean() })).mutation(({ input }) => setVideoFeatured(input.id, input.featured)),
    setVideoAccess: adminProcedure.input(z.object({ id: z.number().int().positive(), accessType: z.enum(["free", "paid"]), pricePoints: z.number().int().min(0).max(1000000).default(0) })).mutation(({ input }) => setVideoAccess(input.id, input.accessType, input.pricePoints)),
    deleteVideo: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => setVideoDeleted(input.id, true)),
    restoreVideo: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => setVideoDeleted(input.id, false)),
    captchaRewardVisibility: adminProcedure.query(() => getSiteSettings()),
    setCaptchaRewardVisibility: adminProcedure.input(z.object({ visible: z.boolean() })).mutation(({ input }) => setCaptchaRewardVisible(input.visible)),
    setCaptchaDailyLimit: adminProcedure.input(z.object({ limit: z.number().int().min(1).max(1000) })).mutation(({ input }) => setCaptchaDailyLimit(input.limit)),
    setCaptchaRewardPoints: adminProcedure.input(z.object({ points: z.number().int().min(1).max(10000) })).mutation(({ input }) => setCaptchaRewardPoints(input.points)),
    setPremiumOnly: adminProcedure.input(z.object({ enabled: z.boolean() })).mutation(({ input }) => setPremiumOnly(input.enabled)),
    sendNotification: adminProcedure.input(z.object({ title: z.string().trim().min(1).max(160), message: z.string().trim().min(1).max(2000), category: z.enum(["broadcast", "new_video", "wallet", "security", "system"]).default("broadcast"), recipientOpenId: z.string().trim().nullable().optional(), scheduledFor: z.string().datetime().nullable().optional() })).mutation(async ({ ctx, input }) => { const scheduledFor = input.scheduledFor ? new Date(input.scheduledFor) : null; const notification = await createAppNotification({ title: input.title, message: input.message, category: input.category, recipientOpenId: input.recipientOpenId ?? null, scheduledFor, createdBy: ctx.user.email ?? ctx.user.openId }); const deliver = async () => { if (!notification.recipientOpenId && input.category === "broadcast") { const legacy = await createBroadcastNotification({ title: input.title, message: input.message, createdBy: ctx.user.email ?? ctx.user.openId }); await sendBroadcastPush({ title: input.title, message: input.message, notificationId: legacy.id, category: input.category }); } else await sendUserPush({ title: input.title, message: input.message, notificationId: notification.id, userOpenId: notification.recipientOpenId }); }; if (scheduledFor && scheduledFor.getTime() > Date.now()) setTimeout(() => void deliver(), Math.min(scheduledFor.getTime() - Date.now(), 2147483647)); else void deliver(); return notification; }),
    walletRequests: adminProcedure.query(() => listWalletRequests()),
    reviewWalletRequest: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["approved", "rejected"]), adminNote: z.string().trim().max(500).optional() })).mutation(async ({ input }) => { const request = await setWalletRequestStatus(input.id, input.status, input.adminNote); if (request?.userOpenId) { const notification = await createAppNotification({ recipientOpenId: request.userOpenId, category: "wallet", title: `${request.type === "withdraw" ? "Withdraw" : "Recharge"} request ${request.status}`, message: request.status === "approved" ? "আপনার wallet request approved হয়েছে।" : "আপনার request rejected হয়েছে এবং reserved balance ফেরত দেওয়া হয়েছে।" }); void sendUserPush({ title: notification.title, message: notification.message, notificationId: notification.id, userOpenId: request.userOpenId }); } return request; }),
    monetizationInvoices: adminProcedure.query(() => listPendingInvoices()),
    approveMembership: adminProcedure.input(z.object({ invoiceId: z.number().int().positive() })).mutation(async ({ ctx, input }) => { const invoice = await approveMembershipInvoice(input.invoiceId); await addAdminActivity({ actorOpenId: ctx.user.openId, actorEmail: ctx.user.email, action: "membership_approved", targetOpenId: invoice.userOpenId, details: invoice.invoiceNumber }); return invoice; }),
    pending: adminProcedure.query(() => listPendingVideos()),
    approve: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const video = await setVideoStatus(input.id, "approved"); if (video) { const notification = await createAppNotification({ category: "new_video", title: "নতুন ভিডিও যোগ হয়েছে", message: `${video.title} এখন xvidos gallery-তে দেখা যাবে।` }); void sendBroadcastPush({ title: notification.title, message: notification.message, notificationId: notification.id, category: "new_video" }); } return video; }),
    reject: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => setVideoStatus(input.id, "rejected")),
    createUpload: adminProcedure
      .input(z.object({ fileName: z.string().min(1).max(255), mimeType: z.string().regex(/^video\//), sizeBytes: z.number().int().positive().max(MAX_VIDEO_BYTES) }))
      .mutation(async ({ input }) => {
        const fileName = safeFileName(input.fileName);
        return { uploadUrl: "/api/admin/videos/upload", fileName, sizeBytes: input.sizeBytes, mimeType: input.mimeType };
      }),
    complete: adminProcedure
      .input(z.object({ storageKey: z.string().regex(/^videos\/[a-zA-Z0-9._-]+$/), fileName: z.string().min(1).max(255), mimeType: z.string().regex(/^video\//), sizeBytes: z.number().int().positive().max(MAX_VIDEO_BYTES), durationSeconds: z.number().int().nonnegative().max(86400).nullable().optional(), qualityVariants: z.array(z.object({ label: z.string().regex(/^\d+p$/), url: z.string().min(1), height: z.number().int().positive() })).max(6).optional(), category: z.string().trim().min(1).max(80).optional(), tags: z.string().trim().max(500).optional() }))
        .mutation(async ({ input }) => {
        try {
          return await insertVideo({ title: input.fileName.replace(/\.[^/.]+$/, ""), fileName: input.fileName, storageKey: input.storageKey, storageUrl: `/manus-storage/${input.storageKey}`, qualityVariants: input.qualityVariants ? JSON.stringify(input.qualityVariants) : null, mimeType: input.mimeType, sizeBytes: input.sizeBytes, durationSeconds: input.durationSeconds ?? null, category: input.category || "General", tags: input.tags || null, status: "approved", visibility: "visible" });
        } catch (error) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error instanceof Error ? error.message : "Could not save video" });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
