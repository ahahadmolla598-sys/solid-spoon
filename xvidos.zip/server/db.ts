import { and, desc, eq, gte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertVideo, User, Video, WalletRequest, InsertWalletRequest, users, videos, walletRequests, siteSettings, SiteSettings, siteNotifications, SiteNotification, appNotifications, notificationReads, notificationPreferences, balanceAuditLogs, BalanceAuditLog, adminActivityLogs, monetizationPlans, userSubscriptions, creatorEarnings, invoices, videoWatchStats, pushKeys, pushSubscriptions, videoLikes, videoFavorites, videoReports } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.lastSeenAt !== undefined) {
    values.lastSeenAt = user.lastSeenAt;
    updateSet.lastSeenAt = user.lastSeenAt;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function touchUser(openId: string): Promise<Date> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db.update(users).set({ lastSeenAt: now }).where(eq(users.openId, openId));
  const user = await getUserByOpenId(openId);
  if (!user) throw new Error("User presence record was not found");
  return user.lastSeenAt;
}

export async function getSiteSettings(): Promise<SiteSettings> {
  const db = await getDb();
  if (!db) return { id: 1, captchaRewardVisible: 1, captchaDailyLimit: 20, captchaRewardPoints: 10, premiumOnly: 0, updatedAt: new Date() } as SiteSettings;
  const result = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
  if (result[0]) return result[0];
  await db.insert(siteSettings).values({ id: 1, captchaRewardVisible: 1, captchaDailyLimit: 20, captchaRewardPoints: 10, premiumOnly: 0 });
  const created = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
  return created[0] as SiteSettings;
}

export async function setPremiumOnly(premiumOnly: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteSettings).values({ id: 1, captchaRewardVisible: 1, captchaDailyLimit: 20, captchaRewardPoints: 10, premiumOnly: premiumOnly ? 1 : 0 }).onDuplicateKeyUpdate({ set: { premiumOnly: premiumOnly ? 1 : 0 } });
  return getSiteSettings();
}

export async function setCaptchaRewardVisible(visible: boolean): Promise<SiteSettings> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteSettings).values({ id: 1, captchaRewardVisible: visible ? 1 : 0 }).onDuplicateKeyUpdate({ set: { captchaRewardVisible: visible ? 1 : 0 } });
  return getSiteSettings();
}

export async function setCaptchaDailyLimit(limit: number): Promise<SiteSettings> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteSettings).values({ id: 1, captchaRewardVisible: 1, captchaDailyLimit: limit }).onDuplicateKeyUpdate({ set: { captchaDailyLimit: limit } });
  return getSiteSettings();
}

export async function setCaptchaRewardPoints(points: number): Promise<SiteSettings> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteSettings).values({ id: 1, captchaRewardVisible: 1, captchaDailyLimit: 20, captchaRewardPoints: points }).onDuplicateKeyUpdate({ set: { captchaRewardPoints: points } });
  return getSiteSettings();
}

export async function createBroadcastNotification(input: { title: string; message: string; createdBy?: string | null }): Promise<SiteNotification> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(siteNotifications).values(input);
  const id = Number((result as unknown as [{ insertId?: number }])[0]?.insertId ?? 0);
  const created = await db.select().from(siteNotifications).where(eq(siteNotifications.id, id)).limit(1);
  if (!created[0]) throw new Error("Notification could not be created");
  return created[0];
}

export async function getLatestBroadcastNotification(): Promise<SiteNotification | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(siteNotifications).orderBy(desc(siteNotifications.createdAt)).limit(1);
  return result[0] ?? null;
}

export async function createAppNotification(input: { recipientOpenId?: string | null; title: string; message: string; category: "broadcast" | "new_video" | "wallet" | "security" | "system"; createdBy?: string | null; scheduledFor?: Date | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(appNotifications).values(input);
  const result = await db.select().from(appNotifications).orderBy(desc(appNotifications.id)).limit(1);
  if (!result[0]) throw new Error("Notification could not be created");
  return result[0];
}

export async function listUserNotifications(userOpenId: string, category?: "broadcast" | "new_video" | "wallet" | "security" | "system") {
  const db = await getDb();
  if (!db) return [];
  const filter = category ? and(eq(appNotifications.category, category), sql`(${appNotifications.recipientOpenId} IS NULL OR ${appNotifications.recipientOpenId} = ${userOpenId})`) : sql`(${appNotifications.recipientOpenId} IS NULL OR ${appNotifications.recipientOpenId} = ${userOpenId})`;
  return db.select({ id: appNotifications.id, title: appNotifications.title, message: appNotifications.message, category: appNotifications.category, createdAt: appNotifications.createdAt, scheduledFor: appNotifications.scheduledFor, readAt: notificationReads.readAt }).from(appNotifications).leftJoin(notificationReads, and(eq(notificationReads.notificationId, appNotifications.id), eq(notificationReads.userOpenId, userOpenId))).where(filter).orderBy(desc(appNotifications.createdAt)).limit(100);
}

export async function markNotificationRead(id: number, userOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(notificationReads).values({ notificationId: id, userOpenId }).onDuplicateKeyUpdate({ set: { readAt: new Date() } });
}

export async function getNotificationPreferences(userOpenId: string) {
  const db = await getDb();
  if (!db) return { broadcast: 1, newVideo: 1, wallet: 1, security: 1 };
  const existing = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userOpenId, userOpenId)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(notificationPreferences).values({ userOpenId });
  return (await db.select().from(notificationPreferences).where(eq(notificationPreferences.userOpenId, userOpenId)).limit(1))[0];
}

export async function setNotificationPreferences(userOpenId: string, values: { broadcast: boolean; newVideo: boolean; wallet: boolean; security: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(notificationPreferences).values({ userOpenId, broadcast: values.broadcast ? 1 : 0, newVideo: values.newVideo ? 1 : 0, wallet: values.wallet ? 1 : 0, security: values.security ? 1 : 0 }).onDuplicateKeyUpdate({ set: { broadcast: values.broadcast ? 1 : 0, newVideo: values.newVideo ? 1 : 0, wallet: values.wallet ? 1 : 0, security: values.security ? 1 : 0 } });
  return getNotificationPreferences(userOpenId);
}

export async function getPushKeys() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select().from(pushKeys).where(eq(pushKeys.id, 1)).limit(1);
  if (existing[0]) return existing[0];
  const { generateVAPIDKeys } = await import("web-push");
  const generated = generateVAPIDKeys();
  await db.insert(pushKeys).values({ id: 1, publicKey: generated.publicKey, privateKey: generated.privateKey });
  const created = await db.select().from(pushKeys).where(eq(pushKeys.id, 1)).limit(1);
  if (!created[0]) throw new Error("Push keys could not be created");
  return created[0];
}

export async function savePushSubscription(input: { endpoint: string; p256dh: string; auth: string; userOpenId?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(pushSubscriptions).values(input).onDuplicateKeyUpdate({ set: { p256dh: input.p256dh, auth: input.auth, userOpenId: input.userOpenId ?? null, updatedAt: new Date() } });
}

export async function deletePushSubscription(endpoint: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
}

export async function listPushSubscriptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pushSubscriptions);
}

export async function listVideos(viewerOpenId?: string | null): Promise<Video[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(videos).where(and(eq(videos.status, "approved"), eq(videos.visibility, "visible"), sql`${videos.deletedAt} IS NULL`)).orderBy(desc(videos.createdAt));
  const settings = await getSiteSettings();
  if (!settings.premiumOnly) return rows;
  const subscription = viewerOpenId ? await getUserSubscription(viewerOpenId) : null;
  if (subscription) return rows;
  return rows.map((video) => video.accessType === "paid" ? { ...video, storageUrl: "", qualityVariants: null } : video);
}

export async function listPendingVideos(): Promise<Video[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(videos).where(eq(videos.status, "pending")).orderBy(desc(videos.createdAt));
}

export async function setVideoStatus(id: number, status: "approved" | "rejected"): Promise<Video | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ status }).where(eq(videos.id, id));
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result[0];
}

export async function listUsers(search = ""): Promise<User[]> {
  const db = await getDb();
  if (!db) return [];
  const term = search.trim();
  return db.select().from(users).where(term ? sql`LOWER(COALESCE(${users.name}, '')) LIKE ${`%${term.toLowerCase()}%`} OR LOWER(COALESCE(${users.email}, '')) LIKE ${`%${term.toLowerCase()}%`} OR ${users.openId} LIKE ${`%${term}%`}` : undefined).orderBy(desc(users.lastSeenAt));
}

export async function addAdminActivity(input: { actorOpenId: string; actorEmail?: string | null; action: string; targetOpenId?: string | null; details?: string | null }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adminActivityLogs).values(input);
}

export async function listAdminActivityLogs() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(adminActivityLogs).orderBy(desc(adminActivityLogs.createdAt)).limit(100);
}

export async function addPoints(openId: string, amount: number): Promise<User | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ points: sql`${users.points} + ${amount}` }).where(eq(users.openId, openId));
  return getUserByOpenId(openId);
}

export async function claimCaptchaReward(openId: string, today: string, dailyLimit: number, rewardPoints: number): Promise<{ user: User; claimsToday: number } | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.update(users).set({
    points: sql`${users.points} + ${rewardPoints}`,
    captchaClaims: sql`IF(${users.captchaClaimDate} = ${today}, ${users.captchaClaims} + 1, 1)`,
    captchaClaimDate: today,
  }).where(and(eq(users.openId, openId), sql`(${users.captchaClaimDate} IS NULL OR ${users.captchaClaimDate} <> ${today} OR ${users.captchaClaims} < ${dailyLimit})`));
  const affectedRows = Number((result as unknown as [{ affectedRows?: number }])[0]?.affectedRows ?? 0);
  if (!affectedRows) return null;
  const user = await getUserByOpenId(openId);
  if (!user) return null;
  await db.insert(balanceAuditLogs).values({ userOpenId: openId, deltaPoints: rewardPoints, kind: "captcha_reward", note: "Captcha reward" });
  return { user, claimsToday: user.captchaClaimDate === today ? user.captchaClaims : 1 };
}

export async function adjustPoints(openId: string, amount: number, actorOpenId?: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.update(users).set({ points: sql`GREATEST(0, ${users.points} + ${amount})` }).where(eq(users.openId, openId));
  const affectedRows = Number((result as unknown as [{ affectedRows?: number }])[0]?.affectedRows ?? 0);
  if (!affectedRows) throw new Error("এই user-এর balance update করা যায়নি: user record পাওয়া যায়নি।");
  await db.insert(balanceAuditLogs).values({ userOpenId: openId, deltaPoints: amount, kind: "admin_adjustment", note: "Admin balance adjustment", actorOpenId: actorOpenId ?? null });
  return getUserByOpenId(openId);
}

export async function setUserBanned(openId: string, banned: boolean): Promise<User | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ banned: banned ? 1 : 0 }).where(eq(users.openId, openId));
  return getUserByOpenId(openId);
}

export async function listAllVideos(): Promise<Video[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(videos).orderBy(desc(videos.createdAt));
}

export async function recordVideoView(videoId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ viewCount: sql`${videos.viewCount} + 1` }).where(and(eq(videos.id, videoId), sql`${videos.deletedAt} IS NULL`));
}

export async function toggleVideoLike(videoId: number, userOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async (tx) => {
    const existing = await tx.select().from(videoLikes).where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.userOpenId, userOpenId))).limit(1);
    const liked = existing.length === 0;
    if (liked) { await tx.insert(videoLikes).values({ videoId, userOpenId }); await tx.update(videos).set({ likeCount: sql`${videos.likeCount} + 1` }).where(eq(videos.id, videoId)); }
    else { await tx.delete(videoLikes).where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.userOpenId, userOpenId))); await tx.update(videos).set({ likeCount: sql`GREATEST(0, ${videos.likeCount} - 1)` }).where(eq(videos.id, videoId)); }
    return { liked };
  });
}

export async function toggleVideoFavorite(videoId: number, userOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async (tx) => {
    const existing = await tx.select().from(videoFavorites).where(and(eq(videoFavorites.videoId, videoId), eq(videoFavorites.userOpenId, userOpenId))).limit(1);
    const favorited = existing.length === 0;
    if (favorited) { await tx.insert(videoFavorites).values({ videoId, userOpenId }); await tx.update(videos).set({ favoriteCount: sql`${videos.favoriteCount} + 1` }).where(eq(videos.id, videoId)); }
    else { await tx.delete(videoFavorites).where(and(eq(videoFavorites.videoId, videoId), eq(videoFavorites.userOpenId, userOpenId))); await tx.update(videos).set({ favoriteCount: sql`GREATEST(0, ${videos.favoriteCount} - 1)` }).where(eq(videos.id, videoId)); }
    return { favorited };
  });
}

export async function getUserVideoCollections(userOpenId: string) {
  const db = await getDb();
  if (!db) return { likedIds: [], favoriteIds: [], recent: [] };
  const [likes, favorites, recent] = await Promise.all([
    db.select({ videoId: videoLikes.videoId }).from(videoLikes).where(eq(videoLikes.userOpenId, userOpenId)),
    db.select({ videoId: videoFavorites.videoId }).from(videoFavorites).where(eq(videoFavorites.userOpenId, userOpenId)),
    db.select({ videoId: videoWatchStats.videoId, lastPositionSeconds: videoWatchStats.lastPositionSeconds, lastWatchedAt: videoWatchStats.lastWatchedAt }).from(videoWatchStats).where(eq(videoWatchStats.userOpenId, userOpenId)).orderBy(desc(videoWatchStats.lastWatchedAt)).limit(20),
  ]);
  return { likedIds: likes.map((entry) => entry.videoId), favoriteIds: favorites.map((entry) => entry.videoId), recent };
}

export async function createVideoReport(input: { videoId: number; userOpenId?: string | null; reason: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(videoReports).values(input);
}

export async function setVideoFeatured(id: number, featured: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ featured: featured ? 1 : 0 }).where(eq(videos.id, id));
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result[0];
}

export async function setVideoDeleted(id: number, deleted: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ deletedAt: deleted ? new Date() : null, visibility: deleted ? "hidden" : "visible" }).where(eq(videos.id, id));
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result[0];
}

export async function setVideoVisibility(id: number, visibility: "visible" | "hidden"): Promise<Video | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ visibility }).where(eq(videos.id, id));
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result[0];
}

export async function createWalletRequest(request: InsertWalletRequest): Promise<WalletRequest> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async (tx) => {
    const debit = await tx.update(users).set({ points: sql`${users.points} - ${request.amountPoints}` }).where(and(eq(users.openId, request.userOpenId), gte(users.points, request.amountPoints)));
    const affectedRows = Number((debit as unknown as [{ affectedRows?: number }])[0]?.affectedRows ?? 0);
    if (!affectedRows) throw new Error("আপনার balance এই request-এর জন্য যথেষ্ট নয়।");
    await tx.insert(walletRequests).values(request);
    await tx.insert(balanceAuditLogs).values({ userOpenId: request.userOpenId, deltaPoints: -request.amountPoints, kind: "wallet_reservation", note: `${request.type} request reserved` });
    const result = await tx.select().from(walletRequests).where(eq(walletRequests.userOpenId, request.userOpenId)).orderBy(desc(walletRequests.createdAt)).limit(1);
    if (!result[0]) throw new Error("Wallet request was not created");
    return result[0];
  });
}

export async function listWalletRequests() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: walletRequests.id, userOpenId: walletRequests.userOpenId, type: walletRequests.type, amountPoints: walletRequests.amountPoints, phoneNumber: walletRequests.phoneNumber, operator: walletRequests.operator, method: walletRequests.method, status: walletRequests.status, adminNote: walletRequests.adminNote, createdAt: walletRequests.createdAt, reviewedAt: walletRequests.reviewedAt, userName: users.name, userEmail: users.email }).from(walletRequests).leftJoin(users, eq(walletRequests.userOpenId, users.openId)).orderBy(desc(walletRequests.createdAt));
}

export async function listUserWalletHistory(openId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(walletRequests).where(eq(walletRequests.userOpenId, openId)).orderBy(desc(walletRequests.createdAt));
}

export async function listBalanceAuditLogs(openId: string): Promise<BalanceAuditLog[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(balanceAuditLogs).where(eq(balanceAuditLogs.userOpenId, openId)).orderBy(desc(balanceAuditLogs.createdAt)).limit(100);
}

export async function setWalletRequestStatus(id: number, status: "approved" | "rejected", adminNote?: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async (tx) => {
    const pending = await tx.select().from(walletRequests).where(and(eq(walletRequests.id, id), eq(walletRequests.status, "pending"))).limit(1);
    const request = pending[0];
    if (!request) {
      const existing = await tx.select().from(walletRequests).where(eq(walletRequests.id, id)).limit(1);
      return existing[0];
    }
    await tx.update(walletRequests).set({ status, reviewedAt: new Date(), adminNote: adminNote ?? null }).where(and(eq(walletRequests.id, id), eq(walletRequests.status, "pending")));
    if (status === "rejected") {
      await tx.update(users).set({ points: sql`${users.points} + ${request.amountPoints}` }).where(eq(users.openId, request.userOpenId));
      await tx.insert(balanceAuditLogs).values({ userOpenId: request.userOpenId, deltaPoints: request.amountPoints, kind: "wallet_refund", note: "Rejected wallet request refunded" });
    }
    const result = await tx.select().from(walletRequests).where(eq(walletRequests.id, id)).limit(1);
    return result[0];
  });
}

export async function insertVideo(video: InsertVideo): Promise<Video> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(videos).values(video);
  const created = await db.select().from(videos).where(eq(videos.storageKey, video.storageKey)).limit(1);
  if (!created[0]) throw new Error("Video record was not created");
  return created[0];
}

export async function setVideoQualityVariants(storageKey: string, qualityVariants: Array<{ label: string; url: string; height: number }>): Promise<void> {
  const db = await getDb();
  if (!db || qualityVariants.length === 0) return;
  await db.update(videos).set({ qualityVariants: JSON.stringify(qualityVariants) }).where(eq(videos.storageKey, storageKey));
}

export async function recordVideoWatch(openId: string, videoId: number, seconds: number, position: number, duration: number | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(videoWatchStats).values({ userOpenId: openId, videoId, secondsWatched: seconds, lastPositionSeconds: position, durationSeconds: duration }).onDuplicateKeyUpdate({ set: {
    secondsWatched: sql`${videoWatchStats.secondsWatched} + ${seconds}`,
    lastPositionSeconds: position,
    durationSeconds: duration,
    lastWatchedAt: new Date(),
  } });
}

export async function listVideoWatchStats() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: videoWatchStats.id,
    userOpenId: videoWatchStats.userOpenId,
    userName: users.name,
    userEmail: users.email,
    videoId: videoWatchStats.videoId,
    videoTitle: videos.title,
    videoFileName: videos.fileName,
    secondsWatched: videoWatchStats.secondsWatched,
    lastPositionSeconds: videoWatchStats.lastPositionSeconds,
    durationSeconds: videoWatchStats.durationSeconds,
    lastWatchedAt: videoWatchStats.lastWatchedAt,
  }).from(videoWatchStats).leftJoin(users, eq(videoWatchStats.userOpenId, users.openId)).leftJoin(videos, eq(videoWatchStats.videoId, videos.id)).orderBy(desc(videoWatchStats.lastWatchedAt));
}


export async function listMonetizationPlans() {
  const db = await getDb();
  if (!db) return [];
  let rows = await db.select().from(monetizationPlans).where(eq(monetizationPlans.active, 1)).orderBy(monetizationPlans.pricePoints);
  if (!rows.length) {
    await db.insert(monetizationPlans).values([
      { slug: "premium-monthly", name: "Premium Membership", description: "Premium access with member-only video access.", pricePoints: 999, durationDays: 30, adFree: 0, active: 1 },
      { slug: "ad-free-monthly", name: "Ad-free Membership", description: "Enjoy the vault without promotional placements.", pricePoints: 499, durationDays: 30, adFree: 1, active: 1 },
    ]);
    rows = await db.select().from(monetizationPlans).where(eq(monetizationPlans.active, 1)).orderBy(monetizationPlans.pricePoints);
  }
  return rows;
}

export async function getUserSubscription(userOpenId: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select({ subscription: userSubscriptions, plan: monetizationPlans }).from(userSubscriptions).leftJoin(monetizationPlans, eq(userSubscriptions.planId, monetizationPlans.id)).where(and(eq(userSubscriptions.userOpenId, userOpenId), eq(userSubscriptions.status, "active"))).orderBy(desc(userSubscriptions.endsAt)).limit(1);
  return rows[0] ?? null;
}

export async function listCreatorEarnings(creatorOpenId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(creatorEarnings).where(eq(creatorEarnings.creatorOpenId, creatorOpenId)).orderBy(desc(creatorEarnings.createdAt)).limit(100);
}

export async function createInvoice(input: { userOpenId: string; itemType: string; itemId?: number | null; amountPoints: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const invoiceNumber = `XV-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  await db.insert(invoices).values({ ...input, invoiceNumber, itemId: input.itemId ?? null });
  return (await db.select().from(invoices).where(eq(invoices.invoiceNumber, invoiceNumber)).limit(1))[0];
}


export async function listPendingInvoices() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(invoices).where(eq(invoices.status, "pending")).orderBy(desc(invoices.createdAt)).limit(100);
}

export async function approveMembershipInvoice(invoiceId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const invoice = (await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1))[0];
  if (!invoice || invoice.status !== "pending" || invoice.itemType !== "membership" || !invoice.itemId) throw new Error("Membership invoice not found");
  const plan = (await db.select().from(monetizationPlans).where(eq(monetizationPlans.id, invoice.itemId)).limit(1))[0];
  if (!plan) throw new Error("Membership plan not found");
  const startsAt = new Date();
  const endsAt = new Date(startsAt.getTime() + plan.durationDays * 86400000);
  await db.insert(userSubscriptions).values({ userOpenId: invoice.userOpenId, planId: plan.id, status: "active", startsAt, endsAt });
  await db.update(invoices).set({ status: "paid" }).where(eq(invoices.id, invoiceId));
  return invoice;
}


export async function setVideoAccess(id: number, accessType: "free" | "paid", pricePoints = 0): Promise<Video | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(videos).set({ accessType, pricePoints: accessType === "paid" ? Math.max(1, pricePoints) : 0 }).where(eq(videos.id, id));
  return (await db.select().from(videos).where(eq(videos.id, id)).limit(1))[0];
}
