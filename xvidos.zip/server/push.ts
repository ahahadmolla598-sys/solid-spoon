import webpush from "web-push";
import { deletePushSubscription, getNotificationPreferences, getPushKeys, listPushSubscriptions } from "./db";

const VAPID_SUBJECT = "mailto:afsiarmd@gmail.com";

export async function getPublicPushKey() {
  const keys = await getPushKeys();
  return keys.publicKey;
}

export async function sendBroadcastPush(input: { title: string; message: string; notificationId: number; category?: "broadcast" | "new_video" | "wallet" | "security" | "system" }) {
  const keys = await getPushKeys();
  webpush.setVapidDetails(VAPID_SUBJECT, keys.publicKey, keys.privateKey);
  const allSubscriptions = await listPushSubscriptions();
  const subscriptions = input.category ? (await Promise.all(allSubscriptions.map(async (subscription) => { if (!subscription.userOpenId) return subscription; const preferences = await getNotificationPreferences(subscription.userOpenId); const key = input.category === "new_video" ? "newVideo" : input.category; return preferences[key as "broadcast" | "newVideo" | "wallet" | "security"] ? subscription : null; }))).filter(Boolean) as typeof allSubscriptions : allSubscriptions;
  await Promise.allSettled(subscriptions.map(async (subscription) => {
    try {
      await webpush.sendNotification({ endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } }, JSON.stringify({ title: input.title, body: input.message, notificationId: input.notificationId, url: "/" }));
    } catch (error) {
      const statusCode = (error as { statusCode?: number }).statusCode;
      if (statusCode === 404 || statusCode === 410) await deletePushSubscription(subscription.endpoint);
      else console.warn("[WebPush] Delivery failed:", statusCode ?? error);
    }
  }));
  return { attempted: subscriptions.length };
}

export async function sendUserPush(input: { title: string; message: string; notificationId: number; userOpenId?: string | null }) {
  const keys = await getPushKeys();
  webpush.setVapidDetails(VAPID_SUBJECT, keys.publicKey, keys.privateKey);
  const subscriptions = (await listPushSubscriptions()).filter((subscription) => !input.userOpenId || subscription.userOpenId === input.userOpenId);
  await Promise.allSettled(subscriptions.map(async (subscription) => {
    try { await webpush.sendNotification({ endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } }, JSON.stringify({ title: input.title, body: input.message, notificationId: input.notificationId, url: "/" })); }
    catch (error) { const statusCode = (error as { statusCode?: number }).statusCode; if (statusCode === 404 || statusCode === 410) await deletePushSubscription(subscription.endpoint); }
  }));
}
