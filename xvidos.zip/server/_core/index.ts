import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { randomUUID } from "crypto";
import { readFile, unlink } from "fs/promises";
import { createWriteStream } from "fs";
import { tmpdir } from "os";
import { basename, extname, join } from "path";
import { pipeline } from "stream/promises";
import { execFile } from "child_process";
import { promisify } from "util";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { storagePut } from "../storage";
import { setVideoQualityVariants } from "../db";
import { sdk } from "./sdk";
import { serveStatic, setupVite } from "./vite";
import { registerStorageProxy } from "./storageProxy";

function safeUploadName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 180) || "video.mp4";
}

const MAX_VIDEO_BYTES = 50 * 1024 * 1024;
const execFileAsync = promisify(execFile);
const QUALITY_TARGETS = [144, 240, 360, 480, 720, 1080] as const;

type QualityVariant = { label: string; url: string; height: number };

async function processQualityVariants(tempPath: string, originalKey: string) {
  try {
    const qualityVariants: QualityVariant[] = [];
    const originalBase = basename(originalKey, extname(originalKey));
    for (const height of QUALITY_TARGETS) {
      const outputPath = join(tmpdir(), `xvidos-${randomUUID()}-${height}p.mp4`);
      try {
        await execFileAsync("ffmpeg", ["-y", "-i", tempPath, "-vf", `scale=-2:${height}:flags=lanczos,unsharp=5:5:0.7:5:5:0.0`, "-c:v", "libx264", "-preset", "slow", "-crf", "19", "-c:a", "aac", "-b:a", "160k", "-pix_fmt", "yuv420p", "-movflags", "+faststart", outputPath]);
        const variant = await storagePut(`videos/qualities/${originalBase}-${height}p.mp4`, await readFile(outputPath), "video/mp4");
        qualityVariants.push({ label: `${height}p`, url: variant.url, height });
      } catch (error) {
        console.warn(`[VideoQuality] ${height}p variant skipped:`, error instanceof Error ? error.message : error);
      } finally {
        await unlink(outputPath).catch(() => undefined);
      }
    }
    if (qualityVariants.length > 0) {
      for (const waitMs of [0, 5000, 15000]) {
        if (waitMs) await new Promise((resolve) => setTimeout(resolve, waitMs));
        await setVideoQualityVariants(originalKey, qualityVariants);
      }
    }
  } finally {
    await unlink(tempPath).catch(() => undefined);
  }
}

async function uploadWithQualityVariants(req: express.Request, fileName: string, mimeType: string): Promise<{ key: string; url: string; qualityVariants: QualityVariant[] }> {
  const tempPath = join(tmpdir(), `xvidos-${randomUUID()}-${fileName}`);
  try {
    await pipeline(req, createWriteStream(tempPath));
    const original = await storagePut(`videos/${fileName}`, await readFile(tempPath), mimeType);
    void processQualityVariants(tempPath, original.key).catch((error) => console.warn("[VideoQuality] background processing failed:", error));
    return { ...original, qualityVariants: [] };
  } catch (error) {
    await unlink(tempPath).catch(() => undefined);
    throw error;
  }
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // JSON parsers do not consume video/* requests; uploads are buffered for transcoding.
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerStorageProxy(app);
  app.put("/api/videos/upload", async (req, res) => {
    const mimeType = String(req.headers["content-type"] || "application/octet-stream").split(";")[0];
    const encodedName = String(req.headers["x-upload-file-name"] || "video.mp4");
    const fileName = safeUploadName(decodeURIComponent(encodedName));
    if (!mimeType.startsWith("video/")) return res.status(415).json({ error: "Only video files are accepted" });
    const contentLength = Number(req.headers["content-length"] || 0);
    if (contentLength === 0) return res.status(400).json({ error: "Video body is empty" });
    if (contentLength > MAX_VIDEO_BYTES) return res.status(413).json({ error: "ভিডিওর সর্বোচ্চ আকার 50 MB।" });
    try {
      return res.json(await uploadWithQualityVariants(req, fileName, mimeType));
    } catch (error) {
      console.error("[VideoUpload] Failed:", error);
      return res.status(502).json({ error: "Video storage upload failed" });
    }
  });
  app.put("/api/admin/videos/upload", async (req, res) => {
    let isAdmin = false;
    try {
      const user = await sdk.authenticateRequest(req);
      isAdmin = user?.email?.toLowerCase() === "afsiarmd@gmail.com";
    } catch {}
    if (!isAdmin) return res.status(403).json({ error: "Admin access required" });
    const mimeType = String(req.headers["content-type"] || "application/octet-stream").split(";")[0];
    const encodedName = String(req.headers["x-upload-file-name"] || "video.mp4");
    const fileName = safeUploadName(decodeURIComponent(encodedName));
    if (!mimeType.startsWith("video/")) return res.status(415).json({ error: "Only video files are accepted" });
    const contentLength = Number(req.headers["content-length"] || 0);
    if (contentLength === 0) return res.status(400).json({ error: "Video body is empty" });
    if (contentLength > MAX_VIDEO_BYTES) return res.status(413).json({ error: "ভিডিওর সর্বোচ্চ আকার 50 MB।" });
    try {
      return res.json(await uploadWithQualityVariants(req, fileName, mimeType));
    } catch (error) {
      console.error("[AdminVideoUpload] Failed:", error);
      return res.status(502).json({ error: "Video storage upload failed" });
    }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
