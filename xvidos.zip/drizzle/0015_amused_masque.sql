CREATE TABLE `appNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientOpenId` varchar(64),
	`title` varchar(160) NOT NULL,
	`message` text NOT NULL,
	`category` enum('broadcast','new_video','wallet','security','system') NOT NULL DEFAULT 'broadcast',
	`createdBy` varchar(320),
	`scheduledFor` timestamp,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `appNotifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notificationPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`broadcast` tinyint NOT NULL DEFAULT 1,
	`newVideo` tinyint NOT NULL DEFAULT 1,
	`wallet` tinyint NOT NULL DEFAULT 1,
	`security` tinyint NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notificationPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `notificationPreferences_userOpenId_unique` UNIQUE(`userOpenId`)
);
--> statement-breakpoint
CREATE TABLE `notificationReads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`notificationId` int NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`readAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notificationReads_id` PRIMARY KEY(`id`),
	CONSTRAINT `notificationReads_notification_user_unique` UNIQUE(`notificationId`,`userOpenId`)
);
