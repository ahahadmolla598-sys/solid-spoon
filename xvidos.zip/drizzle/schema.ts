import { int, mysqlEnum, mysqlTable, text, timestamp, tinyint, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  points: int("points").default(0).notNull(),
  captchaClaims: int("captchaClaims").default(0).notNull(),
  captchaClaimDate: varchar("captchaClaimDate", { length: 10 }),
  banned: tinyint("banned").default(0).notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull().unique(),
  storageUrl: varchar("storageUrl", { length: 1024 }).notNull(),
  qualityVariants: text("qualityVariants"),
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  sizeBytes: int("sizeBytes").notNull(),
  durationSeconds: int("durationSeconds"),
  category: varchar("category", { length: 80 }).default("General").notNull(),
  tags: text("tags"),
  viewCount: int("viewCount").default(0).notNull(),
  likeCount: int("likeCount").default(0).notNull(),
  favoriteCount: int("favoriteCount").default(0).notNull(),
  featured: tinyint("featured").default(0).notNull(),
  accessType: mysqlEnum("accessType", ["free", "paid"]).default("free").notNull(),
  pricePoints: int("pricePoints").default(0).notNull(),
  deletedAt: timestamp("deletedAt"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("approved").notNull(),
  visibility: mysqlEnum("visibility", ["visible", "hidden"]).default("visible").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

export const monetizationPlans = mysqlTable("monetizationPlans", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  pricePoints: int("pricePoints").notNull(),
  durationDays: int("durationDays").notNull(),
  adFree: tinyint("adFree").default(0).notNull(),
  active: tinyint("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const userSubscriptions = mysqlTable("userSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  planId: int("planId").notNull(),
  status: mysqlEnum("status", ["pending", "active", "expired", "cancelled"]).default("pending").notNull(),
  startsAt: timestamp("startsAt"),
  endsAt: timestamp("endsAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const videoPurchases = mysqlTable("videoPurchases", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  videoId: int("videoId").notNull(),
  amountPoints: int("amountPoints").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const promoCodes = mysqlTable("promoCodes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  discountPoints: int("discountPoints").default(0).notNull(),
  discountPercent: int("discountPercent").default(0).notNull(),
  maxUses: int("maxUses").default(1).notNull(),
  usedCount: int("usedCount").default(0).notNull(),
  expiresAt: timestamp("expiresAt"),
  active: tinyint("active").default(1).notNull(),
});

export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerOpenId: varchar("referrerOpenId", { length: 64 }).notNull(),
  referredOpenId: varchar("referredOpenId", { length: 64 }).notNull().unique(),
  commissionPoints: int("commissionPoints").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "paid"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const creatorEarnings = mysqlTable("creatorEarnings", {
  id: int("id").autoincrement().primaryKey(),
  creatorOpenId: varchar("creatorOpenId", { length: 64 }).notNull(),
  videoId: int("videoId"),
  source: mysqlEnum("source", ["paid_video", "sponsored", "referral"]).notNull(),
  amountPoints: int("amountPoints").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "paid"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const sponsoredPlacements = mysqlTable("sponsoredPlacements", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  sponsorName: varchar("sponsorName", { length: 160 }).notNull(),
  budgetPoints: int("budgetPoints").notNull(),
  status: mysqlEnum("status", ["pending", "active", "completed", "rejected"]).default("pending").notNull(),
  startsAt: timestamp("startsAt"),
  endsAt: timestamp("endsAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 40 }).notNull().unique(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  itemType: varchar("itemType", { length: 40 }).notNull(),
  itemId: int("itemId"),
  amountPoints: int("amountPoints").notNull(),
  status: mysqlEnum("status", ["pending", "paid", "void"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const videoLikes = mysqlTable("videoLikes", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ uniqueLike: uniqueIndex("videoLikes_video_user_unique").on(table.videoId, table.userOpenId) }));

export const videoFavorites = mysqlTable("videoFavorites", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ uniqueFavorite: uniqueIndex("videoFavorites_video_user_unique").on(table.videoId, table.userOpenId) }));

export const videoReports = mysqlTable("videoReports", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  userOpenId: varchar("userOpenId", { length: 64 }),
  reason: varchar("reason", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["open", "resolved", "dismissed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const walletRequests = mysqlTable("walletRequests", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  type: mysqlEnum("type", ["withdraw", "recharge"]).notNull(),
  amountPoints: int("amountPoints").notNull(),
  phoneNumber: varchar("phoneNumber", { length: 32 }).notNull(),
  operator: varchar("operator", { length: 32 }),
  method: varchar("method", { length: 32 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  adminNote: text("adminNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export type WalletRequest = typeof walletRequests.$inferSelect;
export type InsertWalletRequest = typeof walletRequests.$inferInsert;

export const balanceAuditLogs = mysqlTable("balanceAuditLogs", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  deltaPoints: int("deltaPoints").notNull(),
  kind: mysqlEnum("kind", ["captcha_reward", "admin_adjustment", "wallet_reservation", "wallet_refund"]).notNull(),
  note: varchar("note", { length: 255 }),
  actorOpenId: varchar("actorOpenId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BalanceAuditLog = typeof balanceAuditLogs.$inferSelect;

export const adminActivityLogs = mysqlTable("adminActivityLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorOpenId: varchar("actorOpenId", { length: 64 }).notNull(),
  actorEmail: varchar("actorEmail", { length: 320 }),
  action: varchar("action", { length: 80 }).notNull(),
  targetOpenId: varchar("targetOpenId", { length: 64 }),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").autoincrement().primaryKey(),
  captchaRewardVisible: tinyint("captchaRewardVisible").default(1).notNull(),
  captchaDailyLimit: int("captchaDailyLimit").default(20).notNull(),
  captchaRewardPoints: int("captchaRewardPoints").default(10).notNull(),
  premiumOnly: tinyint("premiumOnly").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteSettings = typeof siteSettings.$inferSelect;

export const siteNotifications = mysqlTable("siteNotifications", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  message: text("message").notNull(),
  createdBy: varchar("createdBy", { length: 320 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SiteNotification = typeof siteNotifications.$inferSelect;

export const appNotifications = mysqlTable("appNotifications", {
  id: int("id").autoincrement().primaryKey(),
  recipientOpenId: varchar("recipientOpenId", { length: 64 }),
  title: varchar("title", { length: 160 }).notNull(),
  message: text("message").notNull(),
  category: mysqlEnum("category", ["broadcast", "new_video", "wallet", "security", "system"]).default("broadcast").notNull(),
  createdBy: varchar("createdBy", { length: 320 }),
  scheduledFor: timestamp("scheduledFor"),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notificationReads = mysqlTable("notificationReads", {
  id: int("id").autoincrement().primaryKey(),
  notificationId: int("notificationId").notNull(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  readAt: timestamp("readAt").defaultNow().notNull(),
}, (table) => ({ uniqueRead: uniqueIndex("notificationReads_notification_user_unique").on(table.notificationId, table.userOpenId) }));

export const notificationPreferences = mysqlTable("notificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull().unique(),
  broadcast: tinyint("broadcast").default(1).notNull(),
  newVideo: tinyint("newVideo").default(1).notNull(),
  wallet: tinyint("wallet").default(1).notNull(),
  security: tinyint("security").default(1).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const pushKeys = mysqlTable("pushKeys", {
  id: int("id").autoincrement().primaryKey(),
  publicKey: varchar("publicKey", { length: 256 }).notNull(),
  privateKey: varchar("privateKey", { length: 256 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const pushSubscriptions = mysqlTable("pushSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  endpoint: varchar("endpoint", { length: 2048 }).notNull().unique(),
  p256dh: varchar("p256dh", { length: 512 }).notNull(),
  auth: varchar("auth", { length: 512 }).notNull(),
  userOpenId: varchar("userOpenId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PushSubscription = typeof pushSubscriptions.$inferSelect;

export const videoWatchStats = mysqlTable("videoWatchStats", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  videoId: int("videoId").notNull(),
  secondsWatched: int("secondsWatched").default(0).notNull(),
  lastPositionSeconds: int("lastPositionSeconds").default(0).notNull(),
  durationSeconds: int("durationSeconds"),
  lastWatchedAt: timestamp("lastWatchedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ userVideoUnique: uniqueIndex("videoWatchStats_user_video_unique").on(table.userOpenId, table.videoId) }));

export type VideoWatchStat = typeof videoWatchStats.$inferSelect;
