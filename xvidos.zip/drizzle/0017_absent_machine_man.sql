CREATE TABLE `creatorEarnings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorOpenId` varchar(64) NOT NULL,
	`videoId` int,
	`source` enum('paid_video','sponsored','referral') NOT NULL,
	`amountPoints` int NOT NULL,
	`status` enum('pending','approved','paid') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `creatorEarnings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(40) NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`itemType` varchar(40) NOT NULL,
	`itemId` int,
	`amountPoints` int NOT NULL,
	`status` enum('pending','paid','void') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `monetizationPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` text NOT NULL,
	`pricePoints` int NOT NULL,
	`durationDays` int NOT NULL,
	`adFree` tinyint NOT NULL DEFAULT 0,
	`active` tinyint NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `monetizationPlans_id` PRIMARY KEY(`id`),
	CONSTRAINT `monetizationPlans_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `promoCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(40) NOT NULL,
	`discountPoints` int NOT NULL DEFAULT 0,
	`discountPercent` int NOT NULL DEFAULT 0,
	`maxUses` int NOT NULL DEFAULT 1,
	`usedCount` int NOT NULL DEFAULT 0,
	`expiresAt` timestamp,
	`active` tinyint NOT NULL DEFAULT 1,
	CONSTRAINT `promoCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `promoCodes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrerOpenId` varchar(64) NOT NULL,
	`referredOpenId` varchar(64) NOT NULL,
	`commissionPoints` int NOT NULL DEFAULT 0,
	`status` enum('pending','approved','paid') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`),
	CONSTRAINT `referrals_referredOpenId_unique` UNIQUE(`referredOpenId`)
);
--> statement-breakpoint
CREATE TABLE `sponsoredPlacements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`sponsorName` varchar(160) NOT NULL,
	`budgetPoints` int NOT NULL,
	`status` enum('pending','active','completed','rejected') NOT NULL DEFAULT 'pending',
	`startsAt` timestamp,
	`endsAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sponsoredPlacements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userSubscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`planId` int NOT NULL,
	`status` enum('pending','active','expired','cancelled') NOT NULL DEFAULT 'pending',
	`startsAt` timestamp,
	`endsAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userSubscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videoPurchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`videoId` int NOT NULL,
	`amountPoints` int NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoPurchases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `videos` ADD `accessType` enum('free','paid') DEFAULT 'free' NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `pricePoints` int DEFAULT 0 NOT NULL;