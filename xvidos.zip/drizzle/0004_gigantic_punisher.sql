CREATE TABLE `walletRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`type` enum('withdraw','recharge') NOT NULL,
	`amountPoints` int NOT NULL,
	`phoneNumber` varchar(32) NOT NULL,
	`operator` varchar(32),
	`method` varchar(32),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `walletRequests_id` PRIMARY KEY(`id`)
);
