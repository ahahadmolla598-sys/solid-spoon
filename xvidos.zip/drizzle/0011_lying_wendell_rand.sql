CREATE TABLE `balanceAuditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`deltaPoints` int NOT NULL,
	`kind` enum('captcha_reward','admin_adjustment','wallet_reservation','wallet_refund') NOT NULL,
	`note` varchar(255),
	`actorOpenId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `balanceAuditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `walletRequests` ADD `adminNote` text;