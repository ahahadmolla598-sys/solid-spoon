ALTER TABLE `users` ADD `captchaClaims` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `captchaClaimDate` varchar(10);