CREATE TABLE `siteNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(160) NOT NULL,
	`message` text NOT NULL,
	`createdBy` varchar(320),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `siteNotifications_id` PRIMARY KEY(`id`)
);
