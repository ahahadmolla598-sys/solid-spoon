CREATE TABLE `siteSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`captchaRewardVisible` tinyint NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `siteSettings_id` PRIMARY KEY(`id`)
);
