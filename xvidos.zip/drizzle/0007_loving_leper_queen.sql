CREATE TABLE `videoWatchStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`videoId` int NOT NULL,
	`secondsWatched` int NOT NULL DEFAULT 0,
	`lastPositionSeconds` int NOT NULL DEFAULT 0,
	`durationSeconds` int,
	`lastWatchedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `videoWatchStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `videoWatchStats_user_video_unique` UNIQUE(`userOpenId`,`videoId`)
);
