CREATE TABLE `videoFavorites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoFavorites_id` PRIMARY KEY(`id`),
	CONSTRAINT `videoFavorites_video_user_unique` UNIQUE(`videoId`,`userOpenId`)
);
--> statement-breakpoint
CREATE TABLE `videoLikes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoLikes_id` PRIMARY KEY(`id`),
	CONSTRAINT `videoLikes_video_user_unique` UNIQUE(`videoId`,`userOpenId`)
);
--> statement-breakpoint
CREATE TABLE `videoReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`userOpenId` varchar(64),
	`reason` varchar(255) NOT NULL,
	`status` enum('open','resolved','dismissed') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `videos` ADD `category` varchar(80) DEFAULT 'General' NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `tags` text;--> statement-breakpoint
ALTER TABLE `videos` ADD `viewCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `likeCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `favoriteCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `featured` tinyint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `deletedAt` timestamp;